# Dnyaneshwari Pawar - Portfolio Website (HTML/CSS/JS)

This is a pure HTML, CSS, and JavaScript version of the portfolio website.

## Files

- `index.html` - Main HTML file with complete structure
- `styles.css` - Base styling (lines 1-1100)
- `styles-complete.css` - Additional styling for remaining sections
- `script.js` - JavaScript for interactions and animations

## Setup Instructions

### Option 1: Combine CSS Files

1. Copy the content from `styles-complete.css` (starting from line 3)
2. Append it to the end of `styles.css`
3. Delete `styles-complete.css`

### Option 2: Use Both CSS Files

Add both CSS files to your `index.html` in the `<head>` section:

```html
<link rel="stylesheet" href="styles.css">
<link rel="stylesheet" href="styles-complete.css">
```

## Features

✅ Light/Dark theme toggle with localStorage persistence
✅ Smooth scrolling navigation
✅ Animated typing effect in hero section
✅ Canvas-based particle background animation
✅ Scroll-triggered animations for sections
✅ Animated skill progress bars
✅ Mobile responsive design with hamburger menu
✅ Active nav link highlighting on scroll
✅ Intersection Observer for scroll animations

## Browser Support

- Chrome 90+
- Firefox 88+
- Safari 14+
- Edge 90+

## Customization

### Update Personal Information

Edit `index.html`:
- Line 158-168: Hero section name and title
- Line 432-578: Projects (add/remove projects)
- Line 724-792: Education details
- Line 947-957: Contact information

### Change Colors

Edit CSS variables in `styles.css` (lines 14-24):
```css
:root {
    --color-purple-600: #9333ea;
    --color-blue-600: #2563eb;
    /* ... etc */
}
```

### Add/Remove Sections

1. Add HTML section in `index.html`
2. Add corresponding styles in CSS
3. Update navigation links in navbar (line 53-57)
4. Update `navLinks` array in `script.js` (line 13)

## Performance Tips

1. **Optimize Images**: Compress all images before uploading
2. **Lazy Loading**: Add `loading="lazy"` to images
3. **Minify**: Minify CSS and JS for production
4. **CDN**: Host images on a CDN for better performance

## Deployment

### GitHub Pages

1. Create a repository
2. Upload all files
3. Go to Settings → Pages
4. Select branch and folder
5. Your site will be live at `https://username.github.io/repo-name`

### Netlify

1. Drag and drop folder to Netlify
2. Site will be live instantly

### Vercel

1. Import repository
2. Deploy with default settings

## File Structure

```
portfolio/
├── index.html          # Main HTML file
├── styles.css          # Base styles
├── styles-complete.css # Additional styles
├── script.js           # JavaScript
└── README-HTML.md      # This file
```

## License

Free to use and modify for personal use.

## Credits

- Icons: Lucide icons (embedded as SVG)
- Images: Unsplash
- Font: System fonts (-apple-system, BlinkMacSystemFont, etc.)

---

Made with 💜 by Dnyaneshwari Pawar
