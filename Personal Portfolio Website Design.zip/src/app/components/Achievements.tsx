import { motion } from "motion/react";
import { Trophy, Star, Crown, Sparkles, Medal, Award, ExternalLink } from "lucide-react";

const achievements = [
  {
    rank: "Finalist",
    title: "Meta PyTorch OpenEnv Hackathon",
    subtitle: "Grand Finale — Global Competition",
    description: "Competed among thousands of teams worldwide in Meta's official PyTorch hackathon. Reached the Grand Finale, demonstrating cutting-edge AI/ML skills on an international stage.",
    icon: Trophy,
    gradient: "from-blue-500 to-cyan-500",
    glow: "shadow-blue-500/40",
    badge: "🌐 Global",
    badgeColor: "from-blue-600 to-cyan-600",
    stars: 4,
    year: "2024",
    org: "Meta AI / PyTorch",
    emoji: "🏅",
  },
  {
    rank: "2nd Prize",
    title: "IndiaAI Impact GenAI Hackathon",
    subtitle: "Track 3 — StartupSarthi Project",
    description: "Built an AI-powered CA Agent for startups using IBM watsonx and Gemini AI. Won 2nd Prize nationally for solving real-world startup business challenges through Generative AI.",
    icon: Crown,
    gradient: "from-yellow-500 to-orange-500",
    glow: "shadow-yellow-500/40",
    badge: "🏆 National",
    badgeColor: "from-yellow-600 to-orange-600",
    stars: 5,
    year: "2024",
    org: "IndiaAI / Government of India",
    emoji: "🥈",
  },
];

export function Achievements() {
  return (
    <section id="achievements" className="py-24 relative overflow-hidden">
      {/* Background */}
      <div className="absolute inset-0 bg-gradient-to-b from-yellow-50/30 via-orange-50/20 to-purple-50/30 dark:from-yellow-950/10 dark:via-orange-950/10 dark:to-purple-950/10" />

      {/* Floating confetti particles */}
      {[...Array(25)].map((_, i) => (
        <motion.div
          key={i}
          animate={{
            y: [0, -40, 0],
            x: [0, Math.sin(i) * 15, 0],
            rotate: [0, 360],
            opacity: [0.4, 0.8, 0.4],
          }}
          transition={{
            duration: 3 + (i % 3),
            repeat: Infinity,
            delay: i * 0.15,
            ease: "easeInOut",
          }}
          className={`absolute w-2 h-2 rounded-full ${
            i % 4 === 0 ? "bg-yellow-400" :
            i % 4 === 1 ? "bg-purple-400" :
            i % 4 === 2 ? "bg-blue-400" : "bg-pink-400"
          } opacity-50`}
          style={{
            left: `${(i * 37) % 100}%`,
            top: `${(i * 23 + 10) % 80}%`,
          }}
        />
      ))}

      <div className="container mx-auto px-4 relative z-10">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: 50 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.8 }}
          className="text-center mb-16"
        >
          <motion.div
            initial={{ scale: 0 }}
            whileInView={{ scale: 1 }}
            viewport={{ once: true }}
            className="inline-flex items-center gap-2 px-4 py-2 bg-gradient-to-r from-yellow-100 to-orange-100 dark:from-yellow-900/40 dark:to-orange-900/40 rounded-full text-yellow-700 dark:text-yellow-300 text-sm border border-yellow-200 dark:border-yellow-700 mb-4"
          >
            <Trophy className="w-4 h-4" />
            Recognition
          </motion.div>
          <h2
            className="text-5xl lg:text-6xl mb-4 bg-gradient-to-r from-yellow-600 via-orange-600 to-red-600 bg-clip-text text-transparent"
            style={{ fontWeight: 700 }}
          >
            Achievements
          </h2>
          <p className="text-muted-foreground max-w-2xl mx-auto">
            Competing at the highest levels — from global hackathons to national AI competitions.
          </p>
        </motion.div>

        {/* Timeline */}
        <div className="max-w-4xl mx-auto">
          {/* Timeline line */}
          <div className="relative">
            <div className="absolute left-1/2 top-0 bottom-0 w-0.5 bg-gradient-to-b from-blue-500 via-yellow-500 to-orange-500 hidden md:block -translate-x-1/2" />

            <div className="space-y-12">
              {achievements.map((achievement, index) => (
                <motion.div
                  key={index}
                  initial={{ opacity: 0, x: index % 2 === 0 ? -50 : 50 }}
                  whileInView={{ opacity: 1, x: 0 }}
                  viewport={{ once: true }}
                  transition={{ duration: 0.8, delay: index * 0.2 }}
                  className={`relative flex items-center gap-8 ${
                    index % 2 === 0 ? "md:flex-row" : "md:flex-row-reverse"
                  } flex-col`}
                >
                  {/* Card */}
                  <div className="flex-1 group">
                    <motion.div
                      whileHover={{ y: -5, scale: 1.01 }}
                      transition={{ duration: 0.3 }}
                      className="relative"
                    >
                      {/* Glow */}
                      <div className={`absolute -inset-1 bg-gradient-to-r ${achievement.gradient} rounded-3xl blur-xl opacity-30 group-hover:opacity-50 transition-opacity duration-500`} />

                      <div className={`relative bg-white/90 dark:bg-gray-950/90 backdrop-blur-xl rounded-3xl border-2 overflow-hidden shadow-2xl ${achievement.glow} hover:shadow-2xl transition-shadow`}
                        style={{ borderColor: "transparent", backgroundClip: "padding-box" }}
                      >
                        {/* Top gradient bar */}
                        <div className={`h-1.5 bg-gradient-to-r ${achievement.gradient}`} />

                        <div className="p-8">
                          {/* Header */}
                          <div className="flex items-start gap-4 mb-5">
                            <motion.div
                              animate={{ rotate: [0, 8, -8, 0] }}
                              transition={{ duration: 3, repeat: Infinity, ease: "easeInOut", delay: index * 0.5 }}
                              className={`w-16 h-16 bg-gradient-to-br ${achievement.gradient} rounded-2xl flex items-center justify-center shadow-xl flex-shrink-0`}
                            >
                              <achievement.icon className="w-8 h-8 text-white" />
                            </motion.div>

                            <div className="flex-1">
                              <div className="flex items-center gap-2 mb-1">
                                <span className="text-2xl">{achievement.emoji}</span>
                                <span
                                  className={`px-3 py-1 bg-gradient-to-r ${achievement.badgeColor} text-white rounded-full text-sm shadow-lg`}
                                  style={{ fontWeight: 700 }}
                                >
                                  {achievement.rank}
                                </span>
                                <span className="px-2.5 py-1 bg-gray-100 dark:bg-gray-800 rounded-full text-xs text-muted-foreground">
                                  {achievement.year}
                                </span>
                              </div>

                              {/* Stars */}
                              <div className="flex gap-1 mb-2">
                                {[...Array(5)].map((_, i) => (
                                  <motion.div
                                    key={i}
                                    initial={{ opacity: 0, scale: 0 }}
                                    whileInView={{ opacity: 1, scale: 1 }}
                                    viewport={{ once: true }}
                                    transition={{ delay: index * 0.2 + i * 0.08, duration: 0.3 }}
                                  >
                                    <Star
                                      className={`w-4 h-4 ${i < achievement.stars ? "text-yellow-500 fill-yellow-500" : "text-gray-300 dark:text-gray-700"}`}
                                    />
                                  </motion.div>
                                ))}
                              </div>
                            </div>

                            <div className="flex-shrink-0">
                              <span className="px-3 py-1.5 bg-gradient-to-r from-purple-50 to-blue-50 dark:from-purple-900/30 dark:to-blue-900/30 text-purple-700 dark:text-purple-300 rounded-xl text-xs border border-purple-200 dark:border-purple-800">
                                {achievement.badge}
                              </span>
                            </div>
                          </div>

                          <h3 className="text-xl text-foreground mb-1" style={{ fontWeight: 700 }}>
                            {achievement.title}
                          </h3>
                          <p className={`text-sm bg-gradient-to-r ${achievement.gradient} bg-clip-text text-transparent mb-3`} style={{ fontWeight: 600 }}>
                            {achievement.subtitle}
                          </p>
                          <p className="text-muted-foreground text-sm leading-relaxed mb-4">
                            {achievement.description}
                          </p>

                          {/* Org badge */}
                          <div className="flex items-center gap-2">
                            <Medal className="w-4 h-4 text-muted-foreground" />
                            <span className="text-xs text-muted-foreground">{achievement.org}</span>
                          </div>
                        </div>
                      </div>
                    </motion.div>
                  </div>

                  {/* Center dot on timeline */}
                  <motion.div
                    initial={{ scale: 0 }}
                    whileInView={{ scale: 1 }}
                    viewport={{ once: true }}
                    transition={{ duration: 0.4, delay: index * 0.2 + 0.3 }}
                    className="relative z-10 hidden md:block flex-shrink-0"
                  >
                    <div className={`w-10 h-10 bg-gradient-to-br ${achievement.gradient} rounded-full flex items-center justify-center shadow-lg ring-4 ring-white dark:ring-gray-950`}>
                      <Sparkles className="w-5 h-5 text-white" />
                    </div>
                  </motion.div>

                  {/* Year marker */}
                  <div className="flex-1 hidden md:flex items-center justify-center">
                    <motion.div
                      initial={{ opacity: 0 }}
                      whileInView={{ opacity: 1 }}
                      viewport={{ once: true }}
                      transition={{ delay: index * 0.2 + 0.4, duration: 0.5 }}
                      className="text-center"
                    >
                      <div
                        className={`text-4xl bg-gradient-to-r ${achievement.gradient} bg-clip-text text-transparent`}
                        style={{ fontWeight: 800 }}
                      >
                        {achievement.year}
                      </div>
                    </motion.div>
                  </div>
                </motion.div>
              ))}
            </div>
          </div>

          {/* Bottom summary card */}
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.7, delay: 0.5 }}
            className="mt-16 text-center"
          >
            <div className="inline-flex items-center gap-4 px-8 py-5 bg-gradient-to-r from-yellow-50 to-orange-50 dark:from-yellow-950/30 dark:to-orange-950/30 rounded-2xl border border-yellow-200 dark:border-yellow-800/60 shadow-xl">
              {[
                { label: "Global Competitions", value: "2" },
                { label: "Awards Won", value: "2" },
                { label: "Projects on GitHub", value: "8+" },
              ].map((stat, i) => (
                <div key={i} className={`text-center ${i > 0 ? "pl-4 border-l border-yellow-200 dark:border-yellow-800" : ""}`}>
                  <div className="text-2xl text-yellow-600 dark:text-yellow-400" style={{ fontWeight: 700 }}>{stat.value}</div>
                  <div className="text-xs text-muted-foreground">{stat.label}</div>
                </div>
              ))}
            </div>
          </motion.div>
        </div>
      </div>
    </section>
  );
}
