import { motion } from "motion/react";
import { GraduationCap, Calendar, MapPin, BookOpen, Award, Cpu } from "lucide-react";

export function Education() {
  return (
    <section id="education" className="py-24 relative overflow-hidden">
      {/* Background */}
      <div className="absolute inset-0 bg-gradient-to-b from-transparent via-purple-50/30 to-transparent dark:via-purple-950/10" />
      
      {/* Decorative elements */}
      <motion.div
        animate={{
          rotate: [0, 360],
          scale: [1, 1.1, 1],
        }}
        transition={{
          duration: 20,
          repeat: Infinity,
          ease: "linear",
        }}
        className="absolute top-20 right-20 w-40 h-40 border-4 border-purple-200 dark:border-purple-800 rounded-full opacity-20"
      />
      
      <div className="container mx-auto px-4 relative z-10">
        <motion.div
          initial={{ opacity: 0, y: 50 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.8 }}
          className="text-center mb-20"
        >
          <motion.div
            initial={{ scale: 0 }}
            whileInView={{ scale: 1 }}
            viewport={{ once: true }}
            transition={{ duration: 0.5 }}
            className="inline-block mb-4"
          >
            <div className="px-4 py-2 bg-gradient-to-r from-purple-100 to-blue-100 dark:from-purple-900/40 dark:to-blue-900/40 rounded-full text-purple-700 dark:text-purple-300 text-sm border border-purple-200 dark:border-purple-700">
              Academic Background
            </div>
          </motion.div>
          <h2 className="text-5xl lg:text-6xl mb-6 bg-gradient-to-r from-purple-600 via-blue-600 to-pink-600 bg-clip-text text-transparent" style={{ fontWeight: 700 }}>
            Education
          </h2>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ delay: 0.2, duration: 0.8 }}
          className="max-w-4xl mx-auto"
        >
          <div className="relative">
            {/* Timeline line with gradient */}
            <div className="absolute left-12 top-0 bottom-0 w-1 bg-gradient-to-b from-purple-600 via-blue-600 to-pink-600 rounded-full hidden md:block" />
            
            <div className="relative">
              {/* Icon container */}
              <motion.div
                initial={{ scale: 0, rotate: -180 }}
                whileInView={{ scale: 1, rotate: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.6, type: "spring" }}
                className="absolute left-8 top-0 w-20 h-20 bg-gradient-to-br from-purple-600 to-blue-600 rounded-2xl shadow-2xl hidden md:block z-10"
              >
                <div className="flex items-center justify-center w-full h-full">
                  <GraduationCap className="w-10 h-10 text-white" />
                </div>
              </motion.div>
              
              {/* Content card */}
              <div className="md:pl-32">
                <div className="relative group">
                  {/* Glow effect */}
                  <div className="absolute -inset-1 bg-gradient-to-r from-purple-600 via-blue-600 to-pink-600 rounded-3xl blur-xl opacity-20 group-hover:opacity-40 transition-opacity duration-500" />
                  
                  <div className="relative bg-white/80 dark:bg-gray-900/80 backdrop-blur-xl rounded-3xl p-8 md:p-10 border border-purple-200 dark:border-purple-800 shadow-2xl hover:shadow-3xl transition-all duration-500">
                    {/* Degree header */}
                    <div className="flex items-start justify-between gap-4 mb-6">
                      <div className="flex-1">
                        <h3 className="text-2xl md:text-3xl mb-2 text-foreground" style={{ fontWeight: 600 }}>
                          Bachelor of Technology in AI & Machine Learning
                        </h3>
                        <div className="inline-flex items-center gap-2 px-4 py-2 bg-gradient-to-r from-purple-100 to-blue-100 dark:from-purple-900/40 dark:to-blue-900/40 rounded-full border border-purple-200 dark:border-purple-700">
                          <Cpu className="w-4 h-4 text-purple-600 dark:text-purple-400" />
                          <span className="text-sm text-purple-700 dark:text-purple-300" style={{ fontWeight: 600 }}>
                            Minor: Robotics & Automation
                          </span>
                        </div>
                      </div>
                      
                      {/* Mobile icon */}
                      <div className="md:hidden w-16 h-16 bg-gradient-to-br from-purple-600 to-blue-600 rounded-2xl flex items-center justify-center shadow-lg flex-shrink-0">
                        <GraduationCap className="w-8 h-8 text-white" />
                      </div>
                    </div>
                    
                    {/* Info pills */}
                    <div className="flex flex-wrap gap-4 mb-6">
                      <motion.div
                        initial={{ opacity: 0, x: -20 }}
                        whileInView={{ opacity: 1, x: 0 }}
                        viewport={{ once: true }}
                        transition={{ delay: 0.3, duration: 0.5 }}
                        className="flex items-center gap-2 px-4 py-2 bg-white dark:bg-gray-800 rounded-full border border-purple-200 dark:border-purple-800 shadow-sm"
                      >
                        <MapPin className="w-4 h-4 text-purple-600 dark:text-purple-400" />
                        <span className="text-sm text-foreground">Rajarambapu Institute of Technology</span>
                      </motion.div>
                      <motion.div
                        initial={{ opacity: 0, x: -20 }}
                        whileInView={{ opacity: 1, x: 0 }}
                        viewport={{ once: true }}
                        transition={{ delay: 0.4, duration: 0.5 }}
                        className="flex items-center gap-2 px-4 py-2 bg-white dark:bg-gray-800 rounded-full border border-blue-200 dark:border-blue-800 shadow-sm"
                      >
                        <Calendar className="w-4 h-4 text-blue-600 dark:text-blue-400" />
                        <span className="text-sm text-foreground">2023 - 2027</span>
                      </motion.div>
                      <motion.div
                        initial={{ opacity: 0, x: -20 }}
                        whileInView={{ opacity: 1, x: 0 }}
                        viewport={{ once: true }}
                        transition={{ delay: 0.5, duration: 0.5 }}
                        className="flex items-center gap-2 px-4 py-2 bg-white dark:bg-gray-800 rounded-full border border-pink-200 dark:border-pink-800 shadow-sm"
                      >
                        <MapPin className="w-4 h-4 text-pink-600 dark:text-pink-400" />
                        <span className="text-sm text-foreground">Urun-Islampur</span>
                      </motion.div>
                    </div>

                    {/* Course highlights */}
                    <div className="space-y-4">
                      {[
                        { icon: BookOpen, text: "Focusing on AI fundamentals, machine learning algorithms, and neural networks", color: "from-purple-500 to-pink-500" },
                        { icon: Award, text: "Specializing in Natural Language Processing and Chatbot Development", color: "from-blue-500 to-cyan-500" },
                        { icon: Cpu, text: "Minor specialization in Robotics & Automation technologies", color: "from-indigo-500 to-purple-500" },
                        { icon: GraduationCap, text: "Active participant in hackathons and AI innovation challenges", color: "from-violet-500 to-pink-500" },
                      ].map((item, index) => (
                        <motion.div
                          key={index}
                          initial={{ opacity: 0, y: 20 }}
                          whileInView={{ opacity: 1, y: 0 }}
                          viewport={{ once: true }}
                          transition={{ delay: 0.6 + index * 0.1, duration: 0.5 }}
                          whileHover={{ x: 10 }}
                          className="flex items-start gap-4 group/item"
                        >
                          <div className={`flex-shrink-0 w-10 h-10 bg-gradient-to-br ${item.color} rounded-xl flex items-center justify-center shadow-md group-hover/item:scale-110 transition-transform`}>
                            <item.icon className="w-5 h-5 text-white" />
                          </div>
                          <p className="text-foreground pt-2 leading-relaxed">
                            {item.text}
                          </p>
                        </motion.div>
                      ))}
                    </div>

                    {/* Bottom decoration */}
                    <div className="absolute bottom-0 left-0 right-0 h-2 bg-gradient-to-r from-purple-600 via-blue-600 to-pink-600 rounded-b-3xl" />
                  </div>
                </div>
              </div>
            </div>
          </div>
        </motion.div>
      </div>
    </section>
  );
}
