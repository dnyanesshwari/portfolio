import { motion } from "motion/react";
import { Brain, Users, Lightbulb, Target, Sparkles, Heart, Zap, Award, GraduationCap, Code, Globe } from "lucide-react";

const traits = [
  { icon: Brain, title: "Problem Solver", description: "Tackling complex AI challenges with creative approaches", color: "from-purple-500 to-pink-500" },
  { icon: Users, title: "Collaborator", description: "Building impactful solutions with cross-functional teams", color: "from-blue-500 to-cyan-500" },
  { icon: Lightbulb, title: "Innovator", description: "Designing AI systems that push boundaries", color: "from-violet-500 to-purple-500" },
  { icon: Target, title: "Goal-Oriented", description: "Strategic and data-driven decision making", color: "from-indigo-500 to-blue-500" },
  { icon: Heart, title: "Social Impact", description: "Technology for empowerment and equity", color: "from-red-500 to-pink-500" },
  { icon: Globe, title: "Lifelong Learner", description: "Always exploring the cutting edge of AI", color: "from-emerald-500 to-teal-500" },
];

const timeline = [
  {
    year: "2023",
    title: "Started B.Tech in AI & ML",
    description: "Joined Rajarambapu Institute of Technology, diving deep into AI fundamentals.",
    icon: GraduationCap,
    color: "from-purple-500 to-violet-500",
  },
  {
    year: "2024",
    title: "Won IndiaAI Hackathon",
    description: "2nd Prize with StartupSarthi — AI agent for startups using IBM watsonx & Gemini.",
    icon: Award,
    color: "from-yellow-500 to-orange-500",
  },
  {
    year: "2024",
    title: "Meta PyTorch Grand Finale",
    description: "Reached the Grand Finale of Meta's global PyTorch OpenEnv hackathon.",
    icon: Sparkles,
    color: "from-blue-500 to-cyan-500",
  },
  {
    year: "2025",
    title: "Building Advanced AI Systems",
    description: "Exploring Agentic AI, RAG, MCP protocols, and multi-agent architectures.",
    icon: Brain,
    color: "from-pink-500 to-rose-500",
  },
];

export function About() {
  return (
    <section id="about" className="py-24 relative overflow-hidden">
      <div className="absolute inset-0 bg-gradient-to-b from-transparent via-purple-50/20 to-transparent dark:via-purple-950/8" />

      <motion.div
        animate={{ scale: [1, 1.08, 1], opacity: [0.2, 0.4, 0.2] }}
        transition={{ duration: 10, repeat: Infinity, ease: "easeInOut" }}
        className="absolute -top-32 -right-32 w-96 h-96 bg-gradient-to-br from-purple-400/20 to-blue-400/20 rounded-full blur-3xl"
      />
      <motion.div
        animate={{ scale: [1.1, 1, 1.1], opacity: [0.15, 0.3, 0.15] }}
        transition={{ duration: 12, repeat: Infinity, ease: "easeInOut", delay: 3 }}
        className="absolute -bottom-32 -left-32 w-80 h-80 bg-gradient-to-br from-blue-400/20 to-pink-400/20 rounded-full blur-3xl"
      />

      <div className="container mx-auto px-4 relative z-10">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: 50 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.8 }}
          className="text-center mb-16"
        >
          <motion.div
            initial={{ scale: 0 }}
            whileInView={{ scale: 1 }}
            viewport={{ once: true }}
            className="inline-flex items-center gap-2 px-4 py-2 bg-gradient-to-r from-purple-100 to-blue-100 dark:from-purple-900/40 dark:to-blue-900/40 rounded-full text-purple-700 dark:text-purple-300 text-sm border border-purple-200 dark:border-purple-700 mb-4"
          >
            <Zap className="w-4 h-4" />
            Get to know me
          </motion.div>
          <h2
            className="text-5xl lg:text-6xl mb-4 bg-gradient-to-r from-purple-600 via-blue-600 to-pink-600 bg-clip-text text-transparent"
            style={{ fontWeight: 700 }}
          >
            About Me
          </h2>
        </motion.div>

        {/* Bio card */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ delay: 0.2, duration: 0.8 }}
          className="max-w-5xl mx-auto mb-16"
        >
          <div className="relative group">
            <div className="absolute -inset-1 bg-gradient-to-r from-purple-600 via-blue-600 to-pink-600 rounded-3xl blur-xl opacity-20 group-hover:opacity-35 transition-opacity duration-500" />

            <div className="relative bg-white/85 dark:bg-gray-950/85 backdrop-blur-xl rounded-3xl p-10 md:p-12 border border-purple-200/60 dark:border-purple-800/60 shadow-2xl">
              <motion.div
                initial={{ scale: 0, rotate: -90 }}
                whileInView={{ scale: 1, rotate: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.5, type: "spring" }}
                className="absolute -top-6 -left-6 w-14 h-14 bg-gradient-to-br from-purple-600 to-blue-600 rounded-2xl shadow-xl flex items-center justify-center"
              >
                <Zap className="w-7 h-7 text-white" />
              </motion.div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-8 items-center">
                <div>
                  <p className="text-lg leading-relaxed text-foreground mb-4">
                    I'm a <span className="bg-gradient-to-r from-purple-600 to-blue-600 bg-clip-text text-transparent" style={{ fontWeight: 700 }}>passionate AI & ML undergraduate</span> building intelligent systems that create real-world impact.
                  </p>
                  <p className="text-foreground leading-relaxed mb-4">
                    My interests span <span style={{ fontWeight: 600 }}>Machine Learning, Deep Learning, LLMs, Reinforcement Learning, Computer Vision, Data Science, AI Agents,</span> and AI-powered applications.
                  </p>
                  <p className="text-muted-foreground leading-relaxed">
                    I enjoy solving challenging problems, participating in hackathons, developing end-to-end AI solutions, and continuously learning emerging AI technologies.
                  </p>
                </div>

                {/* Quick facts */}
                <div className="space-y-3">
                  {[
                    { icon: GraduationCap, label: "Degree", value: "B.Tech — AI & Machine Learning", color: "from-purple-500 to-violet-500" },
                    { icon: Code, label: "Focus", value: "LLMs, AI Agents, Deep Learning", color: "from-blue-500 to-cyan-500" },
                    { icon: Award, label: "Achievements", value: "2 Hackathon Awards (National + Global)", color: "from-yellow-500 to-orange-500" },
                    { icon: Heart, label: "Mission", value: "AI for social empowerment & equity", color: "from-pink-500 to-rose-500" },
                  ].map((fact, i) => (
                    <motion.div
                      key={i}
                      initial={{ opacity: 0, x: 20 }}
                      whileInView={{ opacity: 1, x: 0 }}
                      viewport={{ once: true }}
                      transition={{ delay: 0.4 + i * 0.1, duration: 0.5 }}
                      whileHover={{ x: 4 }}
                      className="flex items-center gap-3 p-3 bg-gray-50/80 dark:bg-gray-900/60 rounded-xl border border-gray-100 dark:border-gray-800/60 group/fact"
                    >
                      <div className={`w-9 h-9 bg-gradient-to-br ${fact.color} rounded-xl flex items-center justify-center flex-shrink-0 shadow-sm group-hover/fact:scale-110 transition-transform`}>
                        <fact.icon className="w-4.5 h-4.5 text-white" />
                      </div>
                      <div>
                        <p className="text-xs text-muted-foreground">{fact.label}</p>
                        <p className="text-sm text-foreground" style={{ fontWeight: 500 }}>{fact.value}</p>
                      </div>
                    </motion.div>
                  ))}
                </div>
              </div>
            </div>
          </div>
        </motion.div>

        {/* Timeline */}
        <div className="max-w-4xl mx-auto mb-16">
          <motion.h3
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="text-center text-2xl text-foreground mb-10"
            style={{ fontWeight: 700 }}
          >
            My Journey
          </motion.h3>

          <div className="relative">
            <div className="absolute left-1/2 top-0 bottom-0 w-0.5 bg-gradient-to-b from-purple-500 via-blue-500 to-pink-500 -translate-x-1/2 hidden md:block" />

            <div className="space-y-8">
              {timeline.map((item, index) => (
                <motion.div
                  key={index}
                  initial={{ opacity: 0, x: index % 2 === 0 ? -40 : 40 }}
                  whileInView={{ opacity: 1, x: 0 }}
                  viewport={{ once: true }}
                  transition={{ delay: index * 0.15, duration: 0.6 }}
                  className={`relative flex items-center gap-6 ${index % 2 === 0 ? "md:flex-row" : "md:flex-row-reverse"} flex-col`}
                >
                  {/* Content */}
                  <motion.div
                    whileHover={{ scale: 1.02, y: -3 }}
                    className="flex-1 group"
                  >
                    <div className="bg-white/85 dark:bg-gray-950/85 backdrop-blur-xl rounded-2xl p-6 border border-purple-200/60 dark:border-purple-800/60 shadow-md hover:shadow-lg transition-all duration-300">
                      <div className="flex items-center gap-3 mb-2">
                        <div className={`w-8 h-8 bg-gradient-to-br ${item.color} rounded-lg flex items-center justify-center shadow-sm`}>
                          <item.icon className="w-4 h-4 text-white" />
                        </div>
                        <span
                          className={`text-sm bg-gradient-to-r ${item.color} bg-clip-text text-transparent`}
                          style={{ fontWeight: 700 }}
                        >
                          {item.year}
                        </span>
                      </div>
                      <h4 className="text-foreground mb-1" style={{ fontWeight: 600 }}>{item.title}</h4>
                      <p className="text-sm text-muted-foreground leading-relaxed">{item.description}</p>
                    </div>
                  </motion.div>

                  {/* Center dot */}
                  <motion.div
                    initial={{ scale: 0 }}
                    whileInView={{ scale: 1 }}
                    viewport={{ once: true }}
                    transition={{ delay: index * 0.15 + 0.3 }}
                    className="w-5 h-5 rounded-full bg-gradient-to-br from-purple-600 to-blue-600 shadow-lg ring-4 ring-white dark:ring-gray-950 hidden md:block flex-shrink-0 z-10"
                  />

                  {/* Empty space for opposite side */}
                  <div className="flex-1 hidden md:block" />
                </motion.div>
              ))}
            </div>
          </div>
        </div>

        {/* Traits grid */}
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4 max-w-6xl mx-auto">
          {traits.map((trait, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 40 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: index * 0.08, duration: 0.5 }}
              whileHover={{ scale: 1.06, y: -5 }}
              className="group relative cursor-default"
            >
              <div className={`absolute -inset-0.5 bg-gradient-to-r ${trait.color} rounded-2xl blur opacity-0 group-hover:opacity-30 transition-opacity duration-300`} />
              <div className="relative bg-white/80 dark:bg-gray-950/80 backdrop-blur-xl rounded-2xl p-5 border border-purple-200/60 dark:border-purple-800/60 shadow-md hover:shadow-lg transition-shadow text-center h-full">
                <motion.div
                  whileHover={{ rotate: 15, scale: 1.1 }}
                  transition={{ duration: 0.4 }}
                  className={`w-12 h-12 bg-gradient-to-br ${trait.color} rounded-xl flex items-center justify-center mx-auto mb-3 shadow-md`}
                >
                  <trait.icon className="w-6 h-6 text-white" />
                </motion.div>
                <h3 className="text-foreground text-sm mb-1" style={{ fontWeight: 600 }}>{trait.title}</h3>
                <p className="text-xs text-muted-foreground leading-relaxed">{trait.description}</p>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
