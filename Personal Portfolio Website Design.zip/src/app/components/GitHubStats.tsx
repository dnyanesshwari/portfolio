import { motion } from "motion/react";
import { Github, Star, GitFork, GitCommit, Code2, Users, BookOpen, Activity } from "lucide-react";
import { useEffect, useRef, useState } from "react";

function Counter({ target, duration = 1500 }: { target: number; duration?: number }) {
  const [count, setCount] = useState(0);
  const ref = useRef<HTMLSpanElement>(null);
  const started = useRef(false);
  useEffect(() => {
    const observer = new IntersectionObserver(([entry]) => {
      if (entry.isIntersecting && !started.current) {
        started.current = true;
        let start = 0;
        const step = (ts: number) => {
          if (!start) start = ts;
          const p = Math.min((ts - start) / duration, 1);
          setCount(Math.floor((1 - Math.pow(1 - p, 3)) * target));
          if (p < 1) requestAnimationFrame(step);
        };
        requestAnimationFrame(step);
      }
    }, { threshold: 0.5 });
    if (ref.current) observer.observe(ref.current);
    return () => observer.disconnect();
  }, [target, duration]);
  return <span ref={ref}>{count}</span>;
}

const stats = [
  { icon: BookOpen, label: "Repositories", value: 20, suffix: "+", color: "from-purple-500 to-violet-500" },
  { icon: GitCommit, label: "Contributions", value: 250, suffix: "+", color: "from-blue-500 to-cyan-500" },
  { icon: Star, label: "Stars Earned", value: 15, suffix: "+", color: "from-yellow-500 to-orange-500" },
  { icon: Users, label: "Followers", value: 12, suffix: "+", color: "from-pink-500 to-rose-500" },
];

const languages = [
  { name: "Python", percent: 72, color: "#3776AB" },
  { name: "Jupyter Notebook", percent: 18, color: "#DA5B0B" },
  { name: "HTML/CSS", percent: 6, color: "#e34c26" },
  { name: "Other", percent: 4, color: "#8b5cf6" },
];

const recentRepos = [
  {
    name: "deepfake-audio-detection",
    description: "Deep Learning models to detect AI-generated fake audio",
    stars: 4,
    forks: 2,
    lang: "Python",
    langColor: "#3776AB",
    updated: "2 days ago",
  },
  {
    name: "dairy-demand-forecasting",
    description: "Festival-aware demand forecasting for dairy cooperatives",
    stars: 3,
    forks: 1,
    lang: "Jupyter Notebook",
    langColor: "#DA5B0B",
    updated: "1 week ago",
  },
  {
    name: "AASHA-AI-chatbot",
    description: "Women safety AI assistant with FastAPI backend",
    stars: 5,
    forks: 2,
    lang: "Python",
    langColor: "#3776AB",
    updated: "3 days ago",
  },
  {
    name: "StratArena-MARL",
    description: "Multi-Agent Reinforcement Learning competition environment",
    stars: 3,
    forks: 1,
    lang: "Python",
    langColor: "#3776AB",
    updated: "2 weeks ago",
  },
];

const activityData = [
  [0,1,2,0,3,1,0],
  [1,2,3,2,1,0,2],
  [2,3,1,0,2,3,1],
  [0,1,2,3,2,1,0],
  [1,0,3,2,1,2,3],
  [2,3,2,1,0,1,2],
  [3,2,1,2,3,2,1],
  [1,2,0,1,2,3,2],
  [0,1,2,3,1,0,1],
  [2,3,1,0,2,1,3],
  [1,2,3,2,1,2,0],
  [3,1,0,2,3,1,2],
];

function ContributionGraph() {
  return (
    <div className="overflow-x-auto">
      <div className="flex gap-1 min-w-max">
        {activityData.map((week, wi) => (
          <div key={wi} className="flex flex-col gap-1">
            {week.map((level, di) => (
              <motion.div
                key={di}
                initial={{ opacity: 0, scale: 0 }}
                whileInView={{ opacity: 1, scale: 1 }}
                viewport={{ once: true }}
                transition={{ delay: (wi * 7 + di) * 0.005, duration: 0.3 }}
                whileHover={{ scale: 1.4 }}
                className={`w-3 h-3 rounded-sm cursor-pointer transition-transform ${
                  level === 0 ? "bg-gray-100 dark:bg-gray-800" :
                  level === 1 ? "bg-purple-200 dark:bg-purple-900" :
                  level === 2 ? "bg-purple-400 dark:bg-purple-700" :
                  "bg-purple-600 dark:bg-purple-500"
                }`}
                title={`${level} contribution${level !== 1 ? "s" : ""}`}
              />
            ))}
          </div>
        ))}
      </div>
      <div className="flex items-center gap-2 mt-3 justify-end">
        <span className="text-xs text-muted-foreground">Less</span>
        {[0,1,2,3].map(l => (
          <div key={l} className={`w-3 h-3 rounded-sm ${
            l === 0 ? "bg-gray-100 dark:bg-gray-800" :
            l === 1 ? "bg-purple-200 dark:bg-purple-900" :
            l === 2 ? "bg-purple-400 dark:bg-purple-700" :
            "bg-purple-600 dark:bg-purple-500"
          }`} />
        ))}
        <span className="text-xs text-muted-foreground">More</span>
      </div>
    </div>
  );
}

export function GitHubStats() {
  return (
    <section id="github" className="py-24 relative overflow-hidden">
      <div className="absolute inset-0 bg-gradient-to-b from-gray-50/50 via-purple-50/30 to-gray-50/50 dark:from-gray-950/50 dark:via-purple-950/20 dark:to-gray-950/50" />

      <div className="container mx-auto px-4 relative z-10">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: 50 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.8 }}
          className="text-center mb-16"
        >
          <motion.div
            initial={{ scale: 0 }}
            whileInView={{ scale: 1 }}
            viewport={{ once: true }}
            className="inline-flex items-center gap-2 px-4 py-2 bg-gradient-to-r from-gray-100 to-purple-100 dark:from-gray-800/60 dark:to-purple-900/40 rounded-full text-gray-700 dark:text-gray-300 text-sm border border-gray-200 dark:border-gray-700 mb-4"
          >
            <Github className="w-4 h-4" />
            Open Source
          </motion.div>
          <h2
            className="text-5xl lg:text-6xl mb-4 bg-gradient-to-r from-gray-800 via-purple-700 to-blue-600 dark:from-white dark:via-purple-400 dark:to-blue-400 bg-clip-text text-transparent"
            style={{ fontWeight: 700 }}
          >
            GitHub Activity
          </h2>
          <p className="text-muted-foreground max-w-2xl mx-auto">
            Open source projects, contributions, and coding activity.
          </p>
        </motion.div>

        {/* Stats cards */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 max-w-4xl mx-auto mb-10">
          {stats.map((stat, i) => (
            <motion.div
              key={i}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: i * 0.1, duration: 0.6 }}
              whileHover={{ y: -5, scale: 1.03 }}
              className="group bg-white/80 dark:bg-gray-950/80 backdrop-blur-xl rounded-2xl p-5 border border-purple-200/60 dark:border-purple-800/60 shadow-lg text-center"
            >
              <div className={`w-10 h-10 bg-gradient-to-br ${stat.color} rounded-xl flex items-center justify-center mx-auto mb-3 shadow-md group-hover:scale-110 transition-transform`}>
                <stat.icon className="w-5 h-5 text-white" />
              </div>
              <div
                className={`text-2xl bg-gradient-to-r ${stat.color} bg-clip-text text-transparent`}
                style={{ fontWeight: 700 }}
              >
                <Counter target={stat.value} />{stat.suffix}
              </div>
              <div className="text-xs text-muted-foreground mt-1">{stat.label}</div>
            </motion.div>
          ))}
        </div>

        <div className="max-w-5xl mx-auto grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Contribution graph */}
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.7, delay: 0.2 }}
            className="lg:col-span-2 bg-white/80 dark:bg-gray-950/80 backdrop-blur-xl rounded-3xl p-6 border border-purple-200/60 dark:border-purple-800/60 shadow-lg"
          >
            <div className="flex items-center justify-between mb-5">
              <div>
                <h3 className="text-foreground" style={{ fontWeight: 600 }}>Contribution Activity</h3>
                <p className="text-xs text-muted-foreground mt-0.5">Last 3 months</p>
              </div>
              <div className="flex items-center gap-1.5 px-3 py-1.5 bg-green-50 dark:bg-green-950/30 rounded-full">
                <Activity className="w-3.5 h-3.5 text-green-600 dark:text-green-400" />
                <span className="text-xs text-green-600 dark:text-green-400" style={{ fontWeight: 600 }}>Active</span>
              </div>
            </div>
            <ContributionGraph />
          </motion.div>

          {/* Language breakdown */}
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.7, delay: 0.3 }}
            className="bg-white/80 dark:bg-gray-950/80 backdrop-blur-xl rounded-3xl p-6 border border-purple-200/60 dark:border-purple-800/60 shadow-lg"
          >
            <h3 className="text-foreground mb-5" style={{ fontWeight: 600 }}>Languages</h3>
            {/* Bar chart */}
            <div className="flex rounded-xl overflow-hidden h-4 mb-5">
              {languages.map((lang, i) => (
                <motion.div
                  key={i}
                  initial={{ width: 0 }}
                  whileInView={{ width: `${lang.percent}%` }}
                  viewport={{ once: true }}
                  transition={{ delay: i * 0.1 + 0.3, duration: 1, ease: "easeOut" }}
                  style={{ backgroundColor: lang.color }}
                  title={`${lang.name}: ${lang.percent}%`}
                />
              ))}
            </div>
            <div className="space-y-2.5">
              {languages.map((lang, i) => (
                <div key={i} className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <div className="w-3 h-3 rounded-full" style={{ backgroundColor: lang.color }} />
                    <span className="text-sm text-foreground">{lang.name}</span>
                  </div>
                  <span className="text-sm text-muted-foreground">{lang.percent}%</span>
                </div>
              ))}
            </div>
          </motion.div>
        </div>

        {/* Pinned repos */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.7, delay: 0.4 }}
          className="max-w-5xl mx-auto mt-6"
        >
          <h3 className="text-foreground mb-4" style={{ fontWeight: 600 }}>Pinned Repositories</h3>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {recentRepos.map((repo, i) => (
              <motion.a
                key={i}
                href="https://github.com/dnyanesshwari"
                target="_blank"
                rel="noopener noreferrer"
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: i * 0.1 + 0.3, duration: 0.5 }}
                whileHover={{ y: -3 }}
                className="bg-white/80 dark:bg-gray-950/80 backdrop-blur-xl rounded-2xl p-5 border border-purple-200/60 dark:border-purple-800/60 shadow-md hover:shadow-lg hover:border-purple-400 dark:hover:border-purple-600 transition-all duration-300 group"
              >
                <div className="flex items-start justify-between mb-3">
                  <div className="flex items-center gap-2">
                    <BookOpen className="w-4 h-4 text-purple-600 dark:text-purple-400" />
                    <span className="text-sm text-purple-700 dark:text-purple-300 group-hover:underline" style={{ fontWeight: 600 }}>
                      {repo.name}
                    </span>
                  </div>
                  <Code2 className="w-4 h-4 text-muted-foreground" />
                </div>
                <p className="text-xs text-muted-foreground mb-4 line-clamp-2 leading-relaxed">{repo.description}</p>
                <div className="flex items-center gap-4">
                  <div className="flex items-center gap-1">
                    <div className="w-3 h-3 rounded-full" style={{ backgroundColor: repo.langColor }} />
                    <span className="text-xs text-muted-foreground">{repo.lang}</span>
                  </div>
                  <div className="flex items-center gap-1">
                    <Star className="w-3.5 h-3.5 text-yellow-500" />
                    <span className="text-xs text-muted-foreground">{repo.stars}</span>
                  </div>
                  <div className="flex items-center gap-1">
                    <GitFork className="w-3.5 h-3.5 text-muted-foreground" />
                    <span className="text-xs text-muted-foreground">{repo.forks}</span>
                  </div>
                  <span className="text-xs text-muted-foreground ml-auto">Updated {repo.updated}</span>
                </div>
              </motion.a>
            ))}
          </div>
        </motion.div>

        {/* CTA */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6, delay: 0.5 }}
          className="text-center mt-10"
        >
          <motion.a
            href="https://github.com/dnyanesshwari"
            target="_blank"
            rel="noopener noreferrer"
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.97 }}
            className="inline-flex items-center gap-3 px-8 py-4 bg-gray-900 dark:bg-white text-white dark:text-gray-900 rounded-full shadow-xl hover:shadow-2xl transition-all"
            style={{ fontWeight: 600 }}
          >
            <Github className="w-5 h-5" />
            View Full GitHub Profile
          </motion.a>
        </motion.div>
      </div>
    </section>
  );
}
