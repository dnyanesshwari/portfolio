import { useState, useEffect } from "react";
import { Menu, X, Sparkles } from "lucide-react";
import { ThemeToggle } from "./ThemeToggle";

const navLinks = [
  { name: "Home", href: "#home" },
  { name: "About", href: "#about" },
  { name: "Projects", href: "#projects" },
  { name: "Skills", href: "#skills" },
  { name: "Contact", href: "#contact" },
];

export function Navbar() {
  const [isScrolled, setIsScrolled] = useState(false);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const [activeSection, setActiveSection] = useState("home");

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 50);
      
      // Update active section based on scroll position
      const sections = navLinks.map(link => link.href.slice(1));
      const currentSection = sections.find(section => {
        const element = document.getElementById(section);
        if (element) {
          const rect = element.getBoundingClientRect();
          return rect.top <= 100 && rect.bottom >= 100;
        }
        return false;
      });
      
      if (currentSection) {
        setActiveSection(currentSection);
      }
    };

    window.addEventListener("scroll", handleScroll);
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  const scrollToSection = (href: string) => {
    setIsMobileMenuOpen(false);
    const element = document.querySelector(href);
    if (element) {
      element.scrollIntoView({ behavior: "smooth" });
    }
  };

  return (
    <>
      <nav
        className={`fixed top-4 left-1/2 transform -translate-x-1/2 z-50 transition-all duration-300 animate-slide-down ${
          isScrolled
            ? "w-auto"
            : "w-auto"
        }`}
      >
        <div className={`relative ${
          isScrolled
            ? "bg-white/80 dark:bg-gray-900/80"
            : "bg-white/60 dark:bg-gray-900/60"
        } backdrop-blur-xl rounded-full shadow-lg border border-purple-200 dark:border-purple-800 transition-all duration-300`}>
          {/* Gradient border effect */}
          <div className="absolute -inset-[1px] bg-gradient-to-r from-purple-600 via-blue-600 to-pink-600 rounded-full opacity-20 blur-sm" />
          
          <div className="relative flex items-center justify-between gap-3 px-4 py-2.5">
            {/* Logo */}
            <a
              href="#home"
              onClick={(e) => {
                e.preventDefault();
                scrollToSection("#home");
              }}
              className="flex items-center cursor-pointer group hover:scale-105 active:scale-95 transition-transform"
            >
              <div className="w-8 h-8 bg-gradient-to-br from-purple-600 via-blue-600 to-pink-600 rounded-full flex items-center justify-center shadow-lg group-hover:shadow-purple-500/50 transition-shadow">
                <Sparkles className="w-4 h-4 text-white" />
              </div>
            </a>

            {/* Desktop Navigation */}
            <div className="hidden md:flex items-center gap-1">
              {navLinks.map((link, index) => {
                const isActive = activeSection === link.href.slice(1);
                return (
                  <a
                    key={index}
                    href={link.href}
                    onClick={(e) => {
                      e.preventDefault();
                      scrollToSection(link.href);
                    }}
                    className={`relative px-3 py-1.5 rounded-full transition-all cursor-pointer text-sm ${
                      isActive
                        ? "text-white bg-gradient-to-r from-purple-600 via-blue-600 to-pink-600 shadow-lg"
                        : "text-foreground hover:text-purple-600 dark:hover:text-purple-400 hover:scale-105"
                    }`}
                    style={{ fontWeight: isActive ? 600 : 500 }}
                  >
                    {link.name}
                  </a>
                );
              })}
            </div>

            {/* Right side - Theme toggle and mobile menu */}
            <div className="flex items-center gap-2">
              <ThemeToggle />
              
              {/* Mobile Menu Button */}
              <button
                onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
                className="md:hidden p-1.5 rounded-full hover:bg-purple-100 dark:hover:bg-purple-900/20 transition-all active:scale-95"
              >
                {isMobileMenuOpen ? (
                  <X className="w-5 h-5 text-foreground" />
                ) : (
                  <Menu className="w-5 h-5 text-foreground" />
                )}
              </button>
            </div>
          </div>
        </div>
      </nav>

      {/* Mobile Menu */}
      {isMobileMenuOpen && (
        <>
          {/* Backdrop */}
          <div
            className="fixed inset-0 bg-black/50 backdrop-blur-sm z-40 md:hidden animate-fade-in"
            onClick={() => setIsMobileMenuOpen(false)}
          />
          
          {/* Menu */}
          <div
            className="fixed top-24 left-1/2 transform -translate-x-1/2 w-[90%] max-w-md bg-white/95 dark:bg-gray-900/95 backdrop-blur-xl rounded-3xl shadow-2xl border border-purple-200 dark:border-purple-800 z-40 md:hidden overflow-hidden animate-slide-in"
          >
              {/* Gradient header */}
              <div className="h-1 bg-gradient-to-r from-purple-600 via-blue-600 to-pink-600" />
              
              <div className="p-6">
                {navLinks.map((link, index) => {
                  const isActive = activeSection === link.href.slice(1);
                  return (
                    <a
                      key={index}
                      href={link.href}
                      onClick={(e) => {
                        e.preventDefault();
                        scrollToSection(link.href);
                      }}
                      className={`block py-3 px-4 rounded-xl mb-2 transition-all cursor-pointer ${
                        isActive
                          ? "bg-gradient-to-r from-purple-600 via-blue-600 to-pink-600 text-white shadow-lg"
                          : "hover:bg-purple-100 dark:hover:bg-purple-900/20 text-foreground"
                      }`}
                      style={{ fontWeight: isActive ? 600 : 500 }}
                    >
                      {link.name}
                    </a>
                  );
                })}
              </div>
          </div>
        </>
      )}
    </>
  );
}
