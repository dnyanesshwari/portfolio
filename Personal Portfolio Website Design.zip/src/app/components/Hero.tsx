import { useEffect, useState, useRef } from "react";
import { motion, useMotionValue, useSpring } from "motion/react";
import { ChevronDown, Sparkles, Code, Cpu, Zap, Github, Linkedin, Download, ArrowRight } from "lucide-react";

const typingTexts = [
  "Machine Learning",
  "Deep Learning",
  "Generative AI",
  "AI Agents",
  "Computer Vision",
  "NLP & LLMs",
  "Reinforcement Learning",
];

function AnimatedCounter({ target, suffix = "" }: { target: number; suffix?: string }) {
  const [count, setCount] = useState(0);
  const ref = useRef<HTMLDivElement>(null);
  const started = useRef(false);

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting && !started.current) {
          started.current = true;
          let start = 0;
          const duration = 1500;
          const step = (timestamp: number) => {
            if (!start) start = timestamp;
            const progress = Math.min((timestamp - start) / duration, 1);
            const eased = 1 - Math.pow(1 - progress, 3);
            setCount(Math.floor(eased * target));
            if (progress < 1) requestAnimationFrame(step);
          };
          requestAnimationFrame(step);
        }
      },
      { threshold: 0.5 }
    );
    if (ref.current) observer.observe(ref.current);
    return () => observer.disconnect();
  }, [target]);

  return <span ref={ref}>{count}{suffix}</span>;
}

export function Hero() {
  const [currentTextIndex, setCurrentTextIndex] = useState(0);
  const [displayedText, setDisplayedText] = useState("");
  const [isDeleting, setIsDeleting] = useState(false);
  const [mousePos, setMousePos] = useState({ x: 0, y: 0 });
  const heroRef = useRef<HTMLElement>(null);

  useEffect(() => {
    const handleMouseMove = (e: MouseEvent) => {
      if (heroRef.current) {
        const rect = heroRef.current.getBoundingClientRect();
        setMousePos({
          x: (e.clientX - rect.left) / rect.width,
          y: (e.clientY - rect.top) / rect.height,
        });
      }
    };
    window.addEventListener("mousemove", handleMouseMove);
    return () => window.removeEventListener("mousemove", handleMouseMove);
  }, []);

  useEffect(() => {
    const currentFullText = typingTexts[currentTextIndex];
    const typingSpeed = isDeleting ? 40 : 90;

    const timeout = setTimeout(() => {
      if (!isDeleting) {
        setDisplayedText(currentFullText.substring(0, displayedText.length + 1));
        if (displayedText === currentFullText) {
          setTimeout(() => setIsDeleting(true), 1800);
        }
      } else {
        setDisplayedText(currentFullText.substring(0, displayedText.length - 1));
        if (displayedText === "") {
          setIsDeleting(false);
          setCurrentTextIndex((currentTextIndex + 1) % typingTexts.length);
        }
      }
    }, typingSpeed);

    return () => clearTimeout(timeout);
  }, [displayedText, isDeleting, currentTextIndex]);

  const parallaxX = (mousePos.x - 0.5) * 20;
  const parallaxY = (mousePos.y - 0.5) * 20;

  return (
    <section
      id="home"
      ref={heroRef}
      className="min-h-screen relative overflow-hidden"
    >
      <div className="flex items-center justify-center min-h-screen">
        {/* Animated gradient background */}
        <div className="absolute inset-0 bg-gradient-to-br from-purple-50 via-blue-50 to-pink-50 dark:from-gray-950 dark:via-purple-950/40 dark:to-blue-950/30" />

        {/* Mouse-following spotlight */}
        <div
          className="absolute inset-0 opacity-30 pointer-events-none transition-opacity duration-300"
          style={{
            background: `radial-gradient(600px circle at ${mousePos.x * 100}% ${mousePos.y * 100}%, rgba(108,99,255,0.15), transparent 60%)`,
          }}
        />

        {/* Floating orbs with parallax */}
        <div
          className="absolute top-20 left-10 w-24 h-24 bg-gradient-to-br from-purple-400 to-pink-400 rounded-full blur-2xl opacity-50"
          style={{ transform: `translate(${parallaxX * 0.5}px, ${parallaxY * 0.5}px)` }}
        />
        <div
          className="absolute top-40 right-20 w-36 h-36 bg-gradient-to-br from-blue-400 to-cyan-400 rounded-full blur-2xl opacity-50"
          style={{ transform: `translate(${-parallaxX * 0.3}px, ${-parallaxY * 0.3}px)` }}
        />
        <div
          className="absolute bottom-32 left-1/4 w-28 h-28 bg-gradient-to-br from-pink-400 to-purple-400 rounded-full blur-2xl opacity-50"
          style={{ transform: `translate(${parallaxX * 0.4}px, ${parallaxY * 0.7}px)` }}
        />
        <div
          className="absolute bottom-20 right-1/3 w-20 h-20 bg-gradient-to-br from-violet-500 to-blue-500 rounded-full blur-xl opacity-40"
          style={{ transform: `translate(${-parallaxX * 0.6}px, ${parallaxY * 0.4}px)` }}
        />

        {/* Geometric shapes */}
        <motion.div
          animate={{ rotate: 360 }}
          transition={{ duration: 30, repeat: Infinity, ease: "linear" }}
          className="absolute top-1/4 right-1/4 w-20 h-20 border-2 border-purple-300 dark:border-purple-700 opacity-30 rounded-sm"
        />
        <motion.div
          animate={{ rotate: -360 }}
          transition={{ duration: 25, repeat: Infinity, ease: "linear" }}
          className="absolute bottom-1/4 left-1/3 w-14 h-14 border-2 border-blue-300 dark:border-blue-700 rounded-full opacity-25"
        />
        <motion.div
          animate={{ rotate: 360, scale: [1, 1.2, 1] }}
          transition={{ duration: 20, repeat: Infinity, ease: "linear" }}
          className="absolute top-1/3 left-1/6 w-10 h-10 border-2 border-pink-300 dark:border-pink-700 opacity-20"
        />

        <div className="container mx-auto px-4 relative z-10">
          <div className="flex flex-col items-center justify-center text-center max-w-5xl mx-auto">

            {/* Badge */}
            <motion.div
              initial={{ opacity: 0, y: -20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: 0.2 }}
              className="inline-flex items-center gap-3 px-6 py-3 bg-white/80 dark:bg-gray-900/80 backdrop-blur-xl rounded-full border border-purple-300 dark:border-purple-700 shadow-xl mb-8"
            >
              <motion.div
                animate={{ rotate: [0, 15, -15, 0] }}
                transition={{ duration: 2, repeat: Infinity, ease: "easeInOut" }}
              >
                <Sparkles className="w-5 h-5 text-purple-600 dark:text-purple-400" />
              </motion.div>
              <span className="text-purple-700 dark:text-purple-300 text-sm">
                Open to Internships & Collaborations
              </span>
              <div className="w-2 h-2 bg-green-500 rounded-full animate-pulse" />
            </motion.div>

            {/* Main heading */}
            <motion.h1
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8, delay: 0.4 }}
              className="text-5xl md:text-7xl lg:text-8xl mb-6 bg-gradient-to-r from-purple-600 via-blue-600 to-pink-600 bg-clip-text text-transparent"
              style={{ fontWeight: 800, lineHeight: 1.1 }}
            >
              Dnyaneshwari<br />
              <span className="text-4xl md:text-6xl lg:text-7xl">Pawar</span>
            </motion.h1>

            {/* Role pills */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.7, delay: 0.6 }}
              className="flex flex-wrap items-center justify-center gap-3 mb-8"
            >
              {[
                { icon: Cpu, label: "AI Engineer", color: "purple" },
                { icon: Code, label: "ML Researcher", color: "blue" },
                { icon: Zap, label: "Innovator", color: "pink" },
              ].map(({ icon: Icon, label, color }, i) => (
                <motion.div
                  key={i}
                  whileHover={{ scale: 1.08, y: -2 }}
                  className={`flex items-center gap-2 px-4 py-2 bg-white/60 dark:bg-gray-900/60 backdrop-blur-sm rounded-full border border-${color}-200 dark:border-${color}-700 shadow-md cursor-default`}
                >
                  <Icon className={`w-4 h-4 text-${color}-600 dark:text-${color}-400`} />
                  <span className="text-sm text-foreground" style={{ fontWeight: 500 }}>{label}</span>
                </motion.div>
              ))}
            </motion.div>

            {/* Typing animation */}
            <motion.div
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ duration: 0.7, delay: 0.8 }}
              className="mb-10 px-8 py-4 bg-white/60 dark:bg-gray-900/60 backdrop-blur-md rounded-2xl border border-purple-200 dark:border-purple-800 shadow-lg"
            >
              <div className="flex items-center justify-center gap-3 flex-wrap">
                <span className="text-muted-foreground">Passionate about</span>
                <span
                  className="text-xl bg-gradient-to-r from-purple-600 to-blue-600 bg-clip-text text-transparent min-w-[200px] text-left"
                  style={{ fontWeight: 700 }}
                >
                  {displayedText}
                  <motion.span
                    animate={{ opacity: [1, 0] }}
                    transition={{ duration: 0.6, repeat: Infinity }}
                    className="inline-block ml-0.5 w-0.5 h-6 bg-purple-600 align-middle"
                  />
                </span>
              </div>
            </motion.div>

            {/* Bio text */}
            <motion.p
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.7, delay: 0.9 }}
              className="text-muted-foreground max-w-2xl mx-auto mb-10 leading-relaxed"
            >
              Building intelligent AI systems that solve real-world problems — from ML forecasting and deepfake detection to women's safety AI and multi-agent reinforcement learning.
            </motion.p>

            {/* CTA Buttons */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.7, delay: 1 }}
              className="flex flex-wrap gap-4 justify-center mb-16"
            >
              <motion.a
                href="#projects"
                whileHover={{ scale: 1.05, boxShadow: "0 20px 40px rgba(108,99,255,0.4)" }}
                whileTap={{ scale: 0.97 }}
                onClick={(e) => {
                  e.preventDefault();
                  document.querySelector("#projects")?.scrollIntoView({ behavior: "smooth" });
                }}
                className="group relative px-8 py-4 bg-gradient-to-r from-purple-600 via-blue-600 to-pink-600 text-white rounded-full overflow-hidden shadow-xl"
              >
                <div className="absolute inset-0 bg-gradient-to-r from-pink-600 via-blue-600 to-purple-600 opacity-0 group-hover:opacity-100 transition-opacity duration-300" />
                <span className="relative z-10 flex items-center gap-2" style={{ fontWeight: 600 }}>
                  View My Work
                  <ArrowRight className="w-5 h-5 group-hover:translate-x-1 transition-transform" />
                </span>
              </motion.a>

              <motion.a
                href="https://github.com/dnyanesshwari"
                target="_blank"
                rel="noopener noreferrer"
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.97 }}
                className="flex items-center gap-2 px-8 py-4 bg-white dark:bg-gray-900 text-foreground rounded-full border-2 border-purple-300 dark:border-purple-700 hover:border-purple-500 shadow-lg transition-all duration-300"
                style={{ fontWeight: 600 }}
              >
                <Github className="w-5 h-5" />
                GitHub
              </motion.a>

              <motion.a
                href="https://www.linkedin.com/in/dnyaneshwari-pawar-2986742b8/"
                target="_blank"
                rel="noopener noreferrer"
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.97 }}
                className="flex items-center gap-2 px-8 py-4 bg-blue-600 hover:bg-blue-700 text-white rounded-full shadow-lg transition-all duration-300"
                style={{ fontWeight: 600 }}
              >
                <Linkedin className="w-5 h-5" />
                LinkedIn
              </motion.a>
            </motion.div>

            {/* Stats */}
            <motion.div
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.7, delay: 1.1 }}
              className="grid grid-cols-2 md:grid-cols-4 gap-4 max-w-3xl mx-auto w-full"
            >
              {[
                { value: 8, suffix: "+", label: "AI Projects" },
                { value: 2, suffix: "", label: "Hackathon Awards" },
                { value: 3, suffix: "+", label: "Certifications" },
                { value: 5, suffix: "+", label: "Tech Domains" },
              ].map((stat, i) => (
                <motion.div
                  key={i}
                  whileHover={{ scale: 1.05, y: -4 }}
                  className="bg-white/60 dark:bg-gray-900/60 backdrop-blur-md rounded-2xl p-5 border border-purple-200/60 dark:border-purple-800/60 shadow-lg text-center group cursor-default"
                >
                  <div
                    className="text-3xl bg-gradient-to-r from-purple-600 to-blue-600 bg-clip-text text-transparent mb-1"
                    style={{ fontWeight: 700 }}
                  >
                    <AnimatedCounter target={stat.value} suffix={stat.suffix} />
                  </div>
                  <div className="text-xs text-muted-foreground">{stat.label}</div>
                </motion.div>
              ))}
            </motion.div>
          </div>
        </div>

        {/* Scroll indicator */}
        <div className="absolute bottom-8 left-1/2 transform -translate-x-1/2">
          <motion.div
            initial={{ opacity: 0, y: -10 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 1.5, duration: 0.5 }}
            className="flex flex-col items-center gap-2"
          >
            <span className="text-xs text-muted-foreground tracking-widest uppercase">Scroll</span>
            <motion.div
              animate={{ y: [0, 8, 0] }}
              transition={{ duration: 1.5, repeat: Infinity, ease: "easeInOut" }}
              className="w-6 h-10 border-2 border-purple-400 dark:border-purple-600 rounded-full flex items-start justify-center p-1.5"
            >
              <div className="w-1.5 h-2.5 bg-gradient-to-b from-purple-600 to-blue-600 rounded-full" />
            </motion.div>
          </motion.div>
        </div>
      </div>
    </section>
  );
}
