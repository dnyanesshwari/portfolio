import { useState } from "react";
import { motion, AnimatePresence } from "motion/react";
import { Mail, Phone, Linkedin, Github, Send, MessageCircle, User, FileText, CheckCircle, Loader2, MapPin } from "lucide-react";

const contactInfo = [
  {
    icon: Mail,
    label: "Email",
    value: "dnyaneshwaripawar79@gmail.com",
    link: "mailto:dnyaneshwaripawar79@gmail.com",
    gradient: "from-red-500 to-pink-500",
  },
  {
    icon: Phone,
    label: "Phone",
    value: "+91 7276376115",
    link: "tel:+917276376115",
    gradient: "from-green-500 to-emerald-500",
  },
  {
    icon: MapPin,
    label: "Location",
    value: "Urun-Islampur, Maharashtra, India",
    link: "#",
    gradient: "from-blue-500 to-cyan-500",
  },
];

const socialLinks = [
  {
    icon: Linkedin,
    label: "LinkedIn",
    link: "https://www.linkedin.com/in/dnyaneshwari-pawar-2986742b8/",
    gradient: "from-blue-600 to-blue-700",
  },
  {
    icon: Github,
    label: "GitHub",
    link: "https://github.com/dnyanesshwari",
    gradient: "from-gray-700 to-gray-900",
  },
  {
    icon: Mail,
    label: "Email",
    link: "mailto:dnyaneshwaripawar79@gmail.com",
    gradient: "from-red-500 to-pink-500",
  },
];

type FormState = {
  name: string;
  email: string;
  subject: string;
  message: string;
};

type Status = "idle" | "loading" | "success" | "error";

export function Contact() {
  const [form, setForm] = useState<FormState>({ name: "", email: "", subject: "", message: "" });
  const [status, setStatus] = useState<Status>("idle");
  const [errors, setErrors] = useState<Partial<FormState>>({});

  const validate = () => {
    const errs: Partial<FormState> = {};
    if (!form.name.trim()) errs.name = "Name is required";
    if (!form.email.trim()) errs.email = "Email is required";
    else if (!/\S+@\S+\.\S+/.test(form.email)) errs.email = "Please enter a valid email";
    if (!form.subject.trim()) errs.subject = "Subject is required";
    if (!form.message.trim()) errs.message = "Message is required";
    else if (form.message.trim().length < 20) errs.message = "Message must be at least 20 characters";
    setErrors(errs);
    return Object.keys(errs).length === 0;
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!validate()) return;
    setStatus("loading");
    // Simulate form submission
    await new Promise(res => setTimeout(res, 1800));
    setStatus("success");
    setForm({ name: "", email: "", subject: "", message: "" });
    setTimeout(() => setStatus("idle"), 5000);
  };

  const handleChange = (field: keyof FormState) => (
    e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>
  ) => {
    setForm(prev => ({ ...prev, [field]: e.target.value }));
    if (errors[field]) setErrors(prev => ({ ...prev, [field]: undefined }));
  };

  return (
    <section id="contact" className="py-24 relative overflow-hidden">
      <div className="absolute inset-0 bg-gradient-to-b from-blue-50/40 via-purple-50/40 to-pink-50/40 dark:from-blue-950/15 dark:via-purple-950/15 dark:to-pink-950/15" />

      <motion.div
        animate={{ scale: [1, 1.2, 1], rotate: [0, 90, 180, 270, 360] }}
        transition={{ duration: 25, repeat: Infinity, ease: "linear" }}
        className="absolute top-20 right-10 w-64 h-64 bg-gradient-to-br from-purple-300/15 to-pink-300/15 dark:from-purple-700/10 dark:to-pink-700/10 rounded-full blur-3xl"
      />
      <motion.div
        animate={{ scale: [1.1, 1, 1.1] }}
        transition={{ duration: 12, repeat: Infinity, ease: "easeInOut" }}
        className="absolute bottom-20 left-10 w-48 h-48 bg-gradient-to-br from-blue-300/15 to-purple-300/15 dark:from-blue-700/10 dark:to-purple-700/10 rounded-full blur-3xl"
      />

      <div className="container mx-auto px-4 relative z-10">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: 50 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.8 }}
          className="text-center mb-16"
        >
          <motion.div
            initial={{ scale: 0 }}
            whileInView={{ scale: 1 }}
            viewport={{ once: true }}
            className="inline-flex items-center gap-2 px-4 py-2 bg-gradient-to-r from-purple-100 to-pink-100 dark:from-purple-900/40 dark:to-pink-900/40 rounded-full text-purple-700 dark:text-purple-300 text-sm border border-purple-200 dark:border-purple-700 mb-4"
          >
            <MessageCircle className="w-4 h-4" />
            Let's Connect
          </motion.div>
          <h2
            className="text-5xl lg:text-6xl mb-4 bg-gradient-to-r from-purple-600 via-blue-600 to-pink-600 bg-clip-text text-transparent"
            style={{ fontWeight: 700 }}
          >
            Get In Touch
          </h2>
          <p className="text-muted-foreground max-w-2xl mx-auto">
            Open to internships, collaborations, research opportunities, and interesting AI conversations. Let's build something intelligent together!
          </p>
        </motion.div>

        <div className="max-w-6xl mx-auto grid grid-cols-1 lg:grid-cols-5 gap-8">
          {/* Left — contact info */}
          <motion.div
            initial={{ opacity: 0, x: -40 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.7, delay: 0.2 }}
            className="lg:col-span-2 space-y-4"
          >
            <h3 className="text-foreground mb-6" style={{ fontWeight: 600 }}>Contact Info</h3>

            {contactInfo.map((info, index) => (
              <motion.a
                key={index}
                href={info.link}
                initial={{ opacity: 0, x: -20 }}
                whileInView={{ opacity: 1, x: 0 }}
                viewport={{ once: true }}
                transition={{ delay: 0.3 + index * 0.1, duration: 0.5 }}
                whileHover={{ x: 6 }}
                className="flex items-center gap-4 p-4 bg-white/80 dark:bg-gray-950/80 backdrop-blur-xl rounded-2xl border border-purple-200/60 dark:border-purple-800/60 shadow-md hover:shadow-lg hover:border-purple-400 dark:hover:border-purple-600 transition-all duration-300 group"
              >
                <div className={`w-12 h-12 bg-gradient-to-br ${info.gradient} rounded-xl flex items-center justify-center flex-shrink-0 shadow-md group-hover:scale-110 transition-transform`}>
                  <info.icon className="w-6 h-6 text-white" />
                </div>
                <div>
                  <p className="text-xs text-muted-foreground mb-0.5">{info.label}</p>
                  <p className="text-sm text-foreground" style={{ fontWeight: 500 }}>{info.value}</p>
                </div>
              </motion.a>
            ))}

            {/* Social links */}
            <div className="pt-4">
              <h3 className="text-foreground mb-4 text-sm" style={{ fontWeight: 600 }}>Find me on</h3>
              <div className="flex gap-3">
                {socialLinks.map((social, i) => (
                  <motion.a
                    key={i}
                    href={social.link}
                    target="_blank"
                    rel="noopener noreferrer"
                    whileHover={{ scale: 1.15, rotate: 5 }}
                    whileTap={{ scale: 0.95 }}
                    className={`w-12 h-12 bg-gradient-to-br ${social.gradient} rounded-xl flex items-center justify-center text-white shadow-lg hover:shadow-xl transition-shadow`}
                    title={social.label}
                  >
                    <social.icon className="w-5 h-5" />
                  </motion.a>
                ))}
              </div>
            </div>

            {/* Response time */}
            <motion.div
              initial={{ opacity: 0, y: 10 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: 0.7, duration: 0.5 }}
              className="flex items-center gap-3 px-4 py-3 bg-green-50 dark:bg-green-950/30 rounded-2xl border border-green-200 dark:border-green-800"
            >
              <div className="w-2.5 h-2.5 bg-green-500 rounded-full animate-pulse" />
              <span className="text-sm text-green-700 dark:text-green-400">
                Typically responds within <strong>24 hours</strong>
              </span>
            </motion.div>
          </motion.div>

          {/* Right — contact form */}
          <motion.div
            initial={{ opacity: 0, x: 40 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.7, delay: 0.3 }}
            className="lg:col-span-3"
          >
            <div className="relative group">
              <div className="absolute -inset-1 bg-gradient-to-r from-purple-600 via-blue-600 to-pink-600 rounded-3xl blur-xl opacity-20 group-hover:opacity-35 transition-opacity duration-500" />

              <div className="relative bg-white/85 dark:bg-gray-950/85 backdrop-blur-xl rounded-3xl p-8 border border-purple-200/60 dark:border-purple-800/60 shadow-xl">
                <AnimatePresence mode="wait">
                  {status === "success" ? (
                    <motion.div
                      key="success"
                      initial={{ opacity: 0, scale: 0.9 }}
                      animate={{ opacity: 1, scale: 1 }}
                      exit={{ opacity: 0, scale: 0.9 }}
                      className="flex flex-col items-center justify-center py-12 text-center"
                    >
                      <motion.div
                        initial={{ scale: 0 }}
                        animate={{ scale: 1 }}
                        transition={{ type: "spring", damping: 15 }}
                        className="w-20 h-20 bg-gradient-to-br from-green-500 to-emerald-500 rounded-full flex items-center justify-center mb-6 shadow-2xl shadow-green-500/30"
                      >
                        <CheckCircle className="w-10 h-10 text-white" />
                      </motion.div>
                      <h3 className="text-2xl text-foreground mb-2" style={{ fontWeight: 700 }}>Message Sent!</h3>
                      <p className="text-muted-foreground">Thank you for reaching out. I'll get back to you soon!</p>
                    </motion.div>
                  ) : (
                    <motion.form
                      key="form"
                      initial={{ opacity: 1 }}
                      exit={{ opacity: 0 }}
                      onSubmit={handleSubmit}
                      className="space-y-5"
                    >
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        {/* Name */}
                        <div>
                          <label className="block text-sm text-foreground mb-1.5" style={{ fontWeight: 500 }}>
                            <User className="inline w-3.5 h-3.5 mr-1 opacity-60" />
                            Name
                          </label>
                          <input
                            type="text"
                            value={form.name}
                            onChange={handleChange("name")}
                            placeholder="Your name"
                            className={`w-full px-4 py-3 bg-gray-50 dark:bg-gray-900/60 rounded-xl border text-foreground placeholder:text-muted-foreground/60 text-sm outline-none transition-all duration-200 focus:border-purple-500 focus:ring-2 focus:ring-purple-500/20 ${
                              errors.name ? "border-red-400" : "border-gray-200 dark:border-gray-800"
                            }`}
                          />
                          {errors.name && <p className="text-red-500 text-xs mt-1">{errors.name}</p>}
                        </div>

                        {/* Email */}
                        <div>
                          <label className="block text-sm text-foreground mb-1.5" style={{ fontWeight: 500 }}>
                            <Mail className="inline w-3.5 h-3.5 mr-1 opacity-60" />
                            Email
                          </label>
                          <input
                            type="email"
                            value={form.email}
                            onChange={handleChange("email")}
                            placeholder="your@email.com"
                            className={`w-full px-4 py-3 bg-gray-50 dark:bg-gray-900/60 rounded-xl border text-foreground placeholder:text-muted-foreground/60 text-sm outline-none transition-all duration-200 focus:border-purple-500 focus:ring-2 focus:ring-purple-500/20 ${
                              errors.email ? "border-red-400" : "border-gray-200 dark:border-gray-800"
                            }`}
                          />
                          {errors.email && <p className="text-red-500 text-xs mt-1">{errors.email}</p>}
                        </div>
                      </div>

                      {/* Subject */}
                      <div>
                        <label className="block text-sm text-foreground mb-1.5" style={{ fontWeight: 500 }}>
                          <FileText className="inline w-3.5 h-3.5 mr-1 opacity-60" />
                          Subject
                        </label>
                        <select
                          value={form.subject}
                          onChange={handleChange("subject")}
                          className={`w-full px-4 py-3 bg-gray-50 dark:bg-gray-900/60 rounded-xl border text-foreground text-sm outline-none transition-all duration-200 focus:border-purple-500 focus:ring-2 focus:ring-purple-500/20 ${
                            errors.subject ? "border-red-400" : "border-gray-200 dark:border-gray-800"
                          }`}
                        >
                          <option value="" className="text-muted-foreground">Select a topic...</option>
                          <option value="Internship Opportunity">Internship Opportunity</option>
                          <option value="Research Collaboration">Research Collaboration</option>
                          <option value="Project Discussion">Project Discussion</option>
                          <option value="Mentorship">Mentorship</option>
                          <option value="Just Saying Hi">Just Saying Hi 👋</option>
                          <option value="Other">Other</option>
                        </select>
                        {errors.subject && <p className="text-red-500 text-xs mt-1">{errors.subject}</p>}
                      </div>

                      {/* Message */}
                      <div>
                        <label className="block text-sm text-foreground mb-1.5" style={{ fontWeight: 500 }}>
                          <MessageCircle className="inline w-3.5 h-3.5 mr-1 opacity-60" />
                          Message
                        </label>
                        <textarea
                          value={form.message}
                          onChange={handleChange("message")}
                          rows={5}
                          placeholder="Tell me about your project or opportunity..."
                          className={`w-full px-4 py-3 bg-gray-50 dark:bg-gray-900/60 rounded-xl border text-foreground placeholder:text-muted-foreground/60 text-sm outline-none transition-all duration-200 focus:border-purple-500 focus:ring-2 focus:ring-purple-500/20 resize-none ${
                            errors.message ? "border-red-400" : "border-gray-200 dark:border-gray-800"
                          }`}
                        />
                        <div className="flex justify-between items-center mt-1">
                          {errors.message ? (
                            <p className="text-red-500 text-xs">{errors.message}</p>
                          ) : (
                            <span />
                          )}
                          <span className={`text-xs ${form.message.length < 20 ? "text-muted-foreground" : "text-green-600 dark:text-green-400"}`}>
                            {form.message.length}/20 min
                          </span>
                        </div>
                      </div>

                      {/* Submit */}
                      <motion.button
                        type="submit"
                        disabled={status === "loading"}
                        whileHover={{ scale: status === "loading" ? 1 : 1.02 }}
                        whileTap={{ scale: status === "loading" ? 1 : 0.98 }}
                        className="w-full py-4 bg-gradient-to-r from-purple-600 via-blue-600 to-pink-600 text-white rounded-2xl shadow-xl hover:shadow-purple-500/30 transition-all duration-300 disabled:opacity-70"
                        style={{ fontWeight: 600 }}
                      >
                        {status === "loading" ? (
                          <span className="flex items-center justify-center gap-2">
                            <Loader2 className="w-5 h-5 animate-spin" />
                            Sending...
                          </span>
                        ) : (
                          <span className="flex items-center justify-center gap-2">
                            <Send className="w-5 h-5" />
                            Send Message
                          </span>
                        )}
                      </motion.button>
                    </motion.form>
                  )}
                </AnimatePresence>
              </div>
            </div>
          </motion.div>
        </div>
      </div>
    </section>
  );
}
