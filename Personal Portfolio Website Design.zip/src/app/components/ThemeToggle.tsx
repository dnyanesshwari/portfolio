import { Moon, Sun } from "lucide-react";
import { Button } from "./ui/button";
import { useEffect, useState } from "react";

export function ThemeToggle() {
  const [isDark, setIsDark] = useState(false);

  useEffect(() => {
    const isDarkMode = document.documentElement.classList.contains("dark");
    setIsDark(isDarkMode);
  }, []);

  const toggleTheme = () => {
    const newIsDark = !isDark;
    setIsDark(newIsDark);
    document.documentElement.classList.toggle("dark", newIsDark);
  };

  return (
    <Button
      variant="ghost"
      size="icon"
      onClick={toggleTheme}
      className="rounded-full hover:bg-purple-100 dark:hover:bg-purple-900/20 transition-colors h-8 w-8"
    >
      {isDark ? (
        <Sun className="h-4 w-4 text-purple-500" />
      ) : (
        <Moon className="h-4 w-4 text-purple-600" />
      )}
    </Button>
  );
}
