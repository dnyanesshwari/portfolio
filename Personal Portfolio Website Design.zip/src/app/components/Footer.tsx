import { motion } from "motion/react";
import { Heart, Github, Linkedin, Mail, ArrowUp, Sparkles } from "lucide-react";

const navLinks = [
  { name: "Home", href: "#home" },
  { name: "About", href: "#about" },
  { name: "Projects", href: "#projects" },
  { name: "Skills", href: "#skills" },
  { name: "GitHub", href: "#github" },
  { name: "Contact", href: "#contact" },
];

export function Footer() {
  const scrollToTop = () => window.scrollTo({ top: 0, behavior: "smooth" });

  return (
    <footer className="relative overflow-hidden border-t border-purple-200/60 dark:border-purple-800/40">
      {/* Background */}
      <div className="absolute inset-0 bg-gradient-to-t from-purple-50/50 to-transparent dark:from-purple-950/20 dark:to-transparent" />

      <div className="container mx-auto px-4 py-12 relative z-10">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-10">
          {/* Brand */}
          <div>
            <div className="flex items-center gap-2 mb-4">
              <div className="w-8 h-8 bg-gradient-to-br from-purple-600 to-blue-600 rounded-full flex items-center justify-center shadow-md">
                <Sparkles className="w-4 h-4 text-white" />
              </div>
              <span className="bg-gradient-to-r from-purple-600 to-blue-600 bg-clip-text text-transparent" style={{ fontWeight: 700 }}>
                Dnyaneshwari Pawar
              </span>
            </div>
            <p className="text-sm text-muted-foreground leading-relaxed mb-4">
              AI Engineer & ML Researcher building intelligent systems for real-world impact. Passionate about LLMs, AI Agents, and social innovation.
            </p>
            <div className="flex gap-3">
              {[
                { icon: Github, href: "https://github.com/dnyanesshwari", label: "GitHub" },
                { icon: Linkedin, href: "https://www.linkedin.com/in/dnyaneshwari-pawar-2986742b8/", label: "LinkedIn" },
                { icon: Mail, href: "mailto:dnyaneshwaripawar79@gmail.com", label: "Email" },
              ].map(({ icon: Icon, href, label }) => (
                <motion.a
                  key={label}
                  href={href}
                  target="_blank"
                  rel="noopener noreferrer"
                  whileHover={{ scale: 1.15, y: -2 }}
                  whileTap={{ scale: 0.95 }}
                  className="w-9 h-9 bg-white dark:bg-gray-900 rounded-xl flex items-center justify-center border border-purple-200 dark:border-purple-800 shadow-sm hover:border-purple-400 hover:shadow-purple-500/20 hover:shadow-md transition-all"
                  title={label}
                >
                  <Icon className="w-4 h-4 text-purple-600 dark:text-purple-400" />
                </motion.a>
              ))}
            </div>
          </div>

          {/* Quick links */}
          <div>
            <h3 className="text-foreground mb-4 text-sm" style={{ fontWeight: 600 }}>Quick Links</h3>
            <div className="grid grid-cols-2 gap-2">
              {navLinks.map((link) => (
                <motion.a
                  key={link.name}
                  href={link.href}
                  onClick={(e) => {
                    e.preventDefault();
                    document.querySelector(link.href)?.scrollIntoView({ behavior: "smooth" });
                  }}
                  whileHover={{ x: 4 }}
                  className="text-sm text-muted-foreground hover:text-purple-600 dark:hover:text-purple-400 transition-colors cursor-pointer flex items-center gap-1"
                >
                  <span className="w-1 h-1 bg-purple-400 rounded-full" />
                  {link.name}
                </motion.a>
              ))}
            </div>
          </div>

          {/* Status */}
          <div>
            <h3 className="text-foreground mb-4 text-sm" style={{ fontWeight: 600 }}>Currently</h3>
            <div className="space-y-3">
              {[
                { dot: "bg-green-500", text: "Open to internships & collaborations" },
                { dot: "bg-blue-500", text: "Studying at RIT, Urun-Islampur" },
                { dot: "bg-purple-500", text: "Learning Agentic AI & MCP" },
                { dot: "bg-yellow-500", text: "Building AI for social impact" },
              ].map((item, i) => (
                <div key={i} className="flex items-center gap-2.5">
                  <div className={`w-2 h-2 ${item.dot} rounded-full animate-pulse`} style={{ animationDelay: `${i * 0.3}s` }} />
                  <span className="text-sm text-muted-foreground">{item.text}</span>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Divider */}
        <div className="h-px bg-gradient-to-r from-transparent via-purple-300 dark:via-purple-700 to-transparent mb-8" />

        {/* Bottom row */}
        <div className="flex flex-col md:flex-row items-center justify-between gap-4">
          <p className="flex items-center gap-2 text-sm text-muted-foreground">
            Made with
            <motion.span
              animate={{ scale: [1, 1.3, 1] }}
              transition={{ duration: 1.5, repeat: Infinity }}
            >
              <Heart className="w-4 h-4 text-pink-500 fill-pink-500" />
            </motion.span>
            and AI by{" "}
            <span className="bg-gradient-to-r from-purple-600 to-blue-600 bg-clip-text text-transparent" style={{ fontWeight: 600 }}>
              Dnyaneshwari Pawar
            </span>
          </p>

          <p className="text-xs text-muted-foreground">
            © {new Date().getFullYear()} — All rights reserved
          </p>

          {/* Scroll to top */}
          <motion.button
            onClick={scrollToTop}
            whileHover={{ scale: 1.1, y: -3 }}
            whileTap={{ scale: 0.95 }}
            className="w-10 h-10 bg-gradient-to-br from-purple-600 to-blue-600 rounded-xl flex items-center justify-center shadow-lg hover:shadow-purple-500/30 transition-shadow"
            title="Scroll to top"
          >
            <ArrowUp className="w-5 h-5 text-white" />
          </motion.button>
        </div>
      </div>
    </footer>
  );
}
