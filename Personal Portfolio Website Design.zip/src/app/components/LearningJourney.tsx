import { motion } from "motion/react";
import { BookOpen, Zap, Target, ArrowRight, Clock, CheckCircle, Loader } from "lucide-react";

type LearningItem = {
  topic: string;
  description: string;
  status: "mastering" | "in-progress" | "upcoming";
  emoji: string;
  gradient: string;
  resources: string[];
  eta?: string;
};

const learningItems: LearningItem[] = [
  {
    topic: "Agentic AI",
    description: "Building autonomous AI agents that can plan, reason, and execute multi-step tasks independently.",
    status: "in-progress",
    emoji: "🤖",
    gradient: "from-purple-600 to-violet-600",
    resources: ["LangChain Agents", "ReAct Pattern", "AutoGPT concepts"],
    eta: "Active",
  },
  {
    topic: "RAG (Retrieval Augmented Generation)",
    description: "Combining vector databases with LLMs to build knowledge-grounded AI applications.",
    status: "in-progress",
    emoji: "📚",
    gradient: "from-blue-600 to-cyan-500",
    resources: ["Chroma DB", "FAISS", "LlamaIndex"],
    eta: "Active",
  },
  {
    topic: "Advanced LLM Engineering",
    description: "Fine-tuning, RLHF, quantization, and deploying large language models at scale.",
    status: "in-progress",
    emoji: "🧬",
    gradient: "from-indigo-600 to-blue-500",
    resources: ["LoRA/QLoRA", "vLLM", "Hugging Face PEFT"],
    eta: "Active",
  },
  {
    topic: "MCP (Model Context Protocol)",
    description: "Anthropic's open protocol for connecting AI models with external tools and data sources.",
    status: "in-progress",
    emoji: "🔗",
    gradient: "from-orange-600 to-amber-500",
    resources: ["Anthropic MCP Spec", "Claude Integration"],
    eta: "Active",
  },
  {
    topic: "Multi-Agent Systems",
    description: "Orchestrating multiple specialized AI agents to solve complex tasks collaboratively.",
    status: "in-progress",
    emoji: "🌐",
    gradient: "from-pink-600 to-rose-500",
    resources: ["AutoGen", "CrewAI", "LangGraph"],
    eta: "Active",
  },
  {
    topic: "Vector Databases",
    description: "Storing and retrieving high-dimensional embeddings for semantic search and AI memory.",
    status: "upcoming",
    emoji: "🗃️",
    gradient: "from-emerald-600 to-teal-500",
    resources: ["Pinecone", "Weaviate", "pgvector"],
    eta: "Q3 2025",
  },
];

const statusConfig = {
  "mastering": { label: "Mastering", icon: CheckCircle, color: "text-green-600 dark:text-green-400", bg: "bg-green-50 dark:bg-green-950/30 border-green-200 dark:border-green-800" },
  "in-progress": { label: "In Progress", icon: Loader, color: "text-blue-600 dark:text-blue-400", bg: "bg-blue-50 dark:bg-blue-950/30 border-blue-200 dark:border-blue-800" },
  "upcoming": { label: "Upcoming", icon: Clock, color: "text-purple-600 dark:text-purple-400", bg: "bg-purple-50 dark:bg-purple-950/30 border-purple-200 dark:border-purple-800" },
};

export function LearningJourney() {
  return (
    <section id="learning" className="py-24 relative overflow-hidden">
      <div className="absolute inset-0 bg-gradient-to-b from-purple-50/30 via-blue-50/30 to-indigo-50/30 dark:from-purple-950/10 dark:via-blue-950/10 dark:to-indigo-950/10" />

      <motion.div
        animate={{ scale: [1, 1.1, 1], opacity: [0.2, 0.4, 0.2] }}
        transition={{ duration: 10, repeat: Infinity, ease: "easeInOut" }}
        className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[600px] bg-gradient-to-r from-purple-400/10 to-blue-400/10 rounded-full blur-3xl"
      />

      <div className="container mx-auto px-4 relative z-10">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: 50 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.8 }}
          className="text-center mb-16"
        >
          <motion.div
            initial={{ scale: 0 }}
            whileInView={{ scale: 1 }}
            viewport={{ once: true }}
            className="inline-flex items-center gap-2 px-4 py-2 bg-gradient-to-r from-purple-100 to-indigo-100 dark:from-purple-900/40 dark:to-indigo-900/40 rounded-full text-purple-700 dark:text-purple-300 text-sm border border-purple-200 dark:border-purple-700 mb-4"
          >
            <Zap className="w-4 h-4" />
            Always Learning
          </motion.div>
          <h2
            className="text-5xl lg:text-6xl mb-4 bg-gradient-to-r from-purple-600 via-indigo-600 to-blue-600 bg-clip-text text-transparent"
            style={{ fontWeight: 700 }}
          >
            Learning Journey
          </h2>
          <p className="text-muted-foreground max-w-2xl mx-auto">
            Continuously pushing the frontier of AI knowledge — here's what I'm actively exploring and mastering.
          </p>
        </motion.div>

        {/* Learning grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 max-w-6xl mx-auto">
          {learningItems.map((item, index) => {
            const status = statusConfig[item.status];
            const StatusIcon = status.icon;

            return (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 40 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: index * 0.1, duration: 0.6 }}
                whileHover={{ y: -6, scale: 1.01 }}
                className="group relative cursor-default"
              >
                {/* Glow */}
                <div className={`absolute -inset-0.5 bg-gradient-to-r ${item.gradient} rounded-3xl blur opacity-0 group-hover:opacity-25 transition-opacity duration-500`} />

                <div className="relative h-full bg-white/85 dark:bg-gray-950/85 backdrop-blur-xl rounded-3xl p-6 border border-purple-200/60 dark:border-purple-800/60 shadow-lg hover:shadow-xl transition-shadow overflow-hidden">
                  {/* Top accent */}
                  <div className={`absolute top-0 left-0 right-0 h-1 bg-gradient-to-r ${item.gradient}`} />

                  {/* Header */}
                  <div className="flex items-start justify-between mb-4">
                    <motion.div
                      animate={{ rotate: [0, 10, -10, 0] }}
                      transition={{ duration: 3, repeat: Infinity, ease: "easeInOut", delay: index * 0.3 }}
                      className="text-3xl"
                    >
                      {item.emoji}
                    </motion.div>

                    <div className={`flex items-center gap-1.5 px-2.5 py-1 rounded-full border text-xs ${status.bg} ${status.color}`} style={{ fontWeight: 500 }}>
                      <StatusIcon className={`w-3 h-3 ${item.status === "in-progress" ? "animate-spin" : ""}`} style={{ animationDuration: "3s" }} />
                      {status.label}
                    </div>
                  </div>

                  <h3 className="text-foreground mb-2" style={{ fontWeight: 700 }}>{item.topic}</h3>
                  <p className="text-sm text-muted-foreground mb-4 leading-relaxed">{item.description}</p>

                  {/* Resources */}
                  <div className="mb-4">
                    <p className="text-xs text-muted-foreground mb-2" style={{ fontWeight: 600 }}>Studying:</p>
                    <div className="flex flex-wrap gap-1.5">
                      {item.resources.map((res, i) => (
                        <span
                          key={i}
                          className="px-2 py-0.5 bg-gray-50 dark:bg-gray-900 text-muted-foreground rounded text-xs border border-gray-200 dark:border-gray-800"
                        >
                          {res}
                        </span>
                      ))}
                    </div>
                  </div>

                  {/* Progress indicator */}
                  <div className="flex items-center gap-2">
                    <div className="flex-1 h-1.5 bg-gray-100 dark:bg-gray-800 rounded-full overflow-hidden">
                      <motion.div
                        initial={{ width: 0 }}
                        whileInView={{ width: item.status === "mastering" ? "90%" : item.status === "in-progress" ? "55%" : "15%" }}
                        viewport={{ once: true }}
                        transition={{ delay: index * 0.1 + 0.5, duration: 1.2, ease: "easeOut" }}
                        className={`h-full bg-gradient-to-r ${item.gradient} rounded-full`}
                      />
                    </div>
                    <span className="text-xs text-muted-foreground flex-shrink-0" style={{ fontWeight: 500 }}>
                      {item.eta}
                    </span>
                  </div>
                </div>
              </motion.div>
            );
          })}
        </div>

        {/* Bottom CTA */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.7, delay: 0.6 }}
          className="text-center mt-14"
        >
          <div className="inline-flex flex-col items-center gap-4">
            <p className="text-muted-foreground">
              The AI space evolves fast — and I evolve with it.
            </p>
            <motion.a
              href="#contact"
              onClick={(e) => {
                e.preventDefault();
                document.querySelector("#contact")?.scrollIntoView({ behavior: "smooth" });
              }}
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.97 }}
              className="inline-flex items-center gap-2 px-6 py-3 bg-gradient-to-r from-purple-600 to-blue-600 text-white rounded-full shadow-lg hover:shadow-purple-500/30 transition-all duration-300"
              style={{ fontWeight: 600 }}
            >
              Let's build something together
              <ArrowRight className="w-4 h-4" />
            </motion.a>
          </div>
        </motion.div>
      </div>
    </section>
  );
}
