import { useState } from "react";
import { motion, AnimatePresence } from "motion/react";
import { Code, Brain, Database, Wrench, BookOpen, Layers } from "lucide-react";

type SkillCategory = {
  id: string;
  icon: React.ElementType;
  title: string;
  description: string;
  color: string;
  gradient: string;
  skills: { name: string; level: number; icon?: string }[];
};

const skillCategories: SkillCategory[] = [
  {
    id: "programming",
    icon: Code,
    title: "Programming",
    description: "Core languages",
    color: "purple",
    gradient: "from-purple-600 to-violet-600",
    skills: [
      { name: "Python", level: 92, icon: "🐍" },
      { name: "C", level: 72, icon: "⚙️" },
      { name: "SQL", level: 82, icon: "🗄️" },
    ],
  },
  {
    id: "ai-ml",
    icon: Brain,
    title: "AI & Machine Learning",
    description: "Core AI expertise",
    color: "blue",
    gradient: "from-blue-600 to-cyan-500",
    skills: [
      { name: "Machine Learning", level: 88, icon: "🧠" },
      { name: "Deep Learning", level: 85, icon: "🔮" },
      { name: "Computer Vision", level: 80, icon: "👁️" },
      { name: "NLP", level: 87, icon: "💬" },
      { name: "Generative AI", level: 85, icon: "✨" },
      { name: "LLMs", level: 82, icon: "🤖" },
      { name: "Prompt Engineering", level: 88, icon: "🎯" },
      { name: "AI Agents", level: 80, icon: "⚡" },
      { name: "Reinforcement Learning", level: 75, icon: "🎮" },
    ],
  },
  {
    id: "data-science",
    icon: Layers,
    title: "Data Science",
    description: "Analytics & modeling",
    color: "violet",
    gradient: "from-violet-600 to-purple-500",
    skills: [
      { name: "Feature Engineering", level: 85, icon: "🔧" },
      { name: "Model Evaluation", level: 86, icon: "📊" },
      { name: "Data Visualization", level: 84, icon: "📈" },
    ],
  },
  {
    id: "libraries",
    icon: BookOpen,
    title: "Libraries & Frameworks",
    description: "ML/AI toolkit",
    color: "pink",
    gradient: "from-pink-600 to-rose-500",
    skills: [
      { name: "Scikit-Learn", level: 88, icon: "🎓" },
      { name: "TensorFlow", level: 82, icon: "🔷" },
      { name: "PyTorch", level: 80, icon: "🔥" },
      { name: "Pandas", level: 90, icon: "🐼" },
      { name: "NumPy", level: 88, icon: "🔢" },
      { name: "Matplotlib", level: 85, icon: "📉" },
      { name: "OpenCV", level: 78, icon: "📷" },
      { name: "Transformers", level: 80, icon: "🤗" },
      { name: "LangChain", level: 82, icon: "⛓️" },
      { name: "FastAPI", level: 80, icon: "⚡" },
      { name: "Flask", level: 78, icon: "🌶️" },
      { name: "Streamlit", level: 88, icon: "🎈" },
    ],
  },
  {
    id: "databases",
    icon: Database,
    title: "Databases",
    description: "Data storage",
    color: "emerald",
    gradient: "from-emerald-600 to-teal-500",
    skills: [
      { name: "SQLite", level: 82, icon: "💾" },
      { name: "PostgreSQL", level: 78, icon: "🐘" },
    ],
  },
  {
    id: "tools",
    icon: Wrench,
    title: "Tools & Platforms",
    description: "Dev environment",
    color: "amber",
    gradient: "from-amber-600 to-orange-500",
    skills: [
      { name: "Git & GitHub", level: 85, icon: "🐙" },
      { name: "Google Colab", level: 90, icon: "🔬" },
      { name: "Jupyter Notebook", level: 90, icon: "📓" },
      { name: "VS Code", level: 88, icon: "💻" },
      { name: "Hugging Face", level: 82, icon: "🤗" },
      { name: "Docker", level: 70, icon: "🐳" },
    ],
  },
];

function SkillBar({ skill, gradient, delay }: { skill: { name: string; level: number; icon?: string }; gradient: string; delay: number }) {
  const [hovered, setHovered] = useState(false);

  return (
    <motion.div
      initial={{ opacity: 0, x: -20 }}
      whileInView={{ opacity: 1, x: 0 }}
      viewport={{ once: true }}
      transition={{ delay, duration: 0.5 }}
      onHoverStart={() => setHovered(true)}
      onHoverEnd={() => setHovered(false)}
      className="group"
    >
      <div className="flex items-center justify-between mb-1.5">
        <span className="text-sm text-foreground flex items-center gap-1.5" style={{ fontWeight: 500 }}>
          {skill.icon && <span className="text-base">{skill.icon}</span>}
          {skill.name}
        </span>
        <motion.span
          animate={{ scale: hovered ? 1.1 : 1 }}
          className={`text-xs px-2 py-0.5 rounded-full bg-gradient-to-r ${gradient} text-white`}
          style={{ fontWeight: 600 }}
        >
          {skill.level}%
        </motion.span>
      </div>
      <div className="h-2 bg-gray-100 dark:bg-gray-800 rounded-full overflow-hidden">
        <motion.div
          initial={{ width: 0 }}
          whileInView={{ width: `${skill.level}%` }}
          viewport={{ once: true }}
          transition={{ delay: delay + 0.2, duration: 1.2, ease: [0.23, 1, 0.32, 1] }}
          className={`h-full bg-gradient-to-r ${gradient} rounded-full relative overflow-hidden`}
        >
          <motion.div
            animate={{ x: ["-100%", "200%"] }}
            transition={{ duration: 2, repeat: Infinity, ease: "linear", delay: delay }}
            className="absolute inset-0 bg-gradient-to-r from-transparent via-white/40 to-transparent"
          />
        </motion.div>
      </div>
    </motion.div>
  );
}

export function Skills() {
  const [activeCategory, setActiveCategory] = useState<string | null>(null);

  return (
    <section id="skills" className="py-24 relative overflow-hidden">
      <div className="absolute inset-0 bg-gradient-to-b from-blue-50/40 via-purple-50/40 to-pink-50/40 dark:from-blue-950/15 dark:via-purple-950/15 dark:to-pink-950/15" />

      <motion.div
        animate={{ scale: [1, 1.15, 1], rotate: [0, 180, 360] }}
        transition={{ duration: 25, repeat: Infinity, ease: "linear" }}
        className="absolute top-10 left-10 w-72 h-72 bg-gradient-to-br from-purple-300/20 to-blue-300/20 dark:from-purple-700/10 dark:to-blue-700/10 rounded-full blur-3xl"
      />
      <motion.div
        animate={{ scale: [1.1, 1, 1.1], rotate: [180, 0, -180] }}
        transition={{ duration: 20, repeat: Infinity, ease: "linear" }}
        className="absolute bottom-10 right-10 w-64 h-64 bg-gradient-to-br from-pink-300/20 to-purple-300/20 dark:from-pink-700/10 dark:to-purple-700/10 rounded-full blur-3xl"
      />

      <div className="container mx-auto px-4 relative z-10">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: 50 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.8 }}
          className="text-center mb-16"
        >
          <motion.div
            initial={{ scale: 0 }}
            whileInView={{ scale: 1 }}
            viewport={{ once: true }}
            className="inline-flex items-center gap-2 px-4 py-2 bg-gradient-to-r from-purple-100 to-blue-100 dark:from-purple-900/40 dark:to-blue-900/40 rounded-full text-purple-700 dark:text-purple-300 text-sm border border-purple-200 dark:border-purple-700 mb-4"
          >
            <Brain className="w-4 h-4" />
            My Expertise
          </motion.div>
          <h2
            className="text-5xl lg:text-6xl mb-4 bg-gradient-to-r from-purple-600 via-blue-600 to-pink-600 bg-clip-text text-transparent"
            style={{ fontWeight: 700 }}
          >
            Skills & Technologies
          </h2>
          <p className="text-muted-foreground max-w-2xl mx-auto">
            A comprehensive toolkit for building intelligent AI systems — from deep learning to deployment.
          </p>
        </motion.div>

        {/* Category tabs */}
        <div className="flex flex-wrap justify-center gap-2 mb-12">
          <motion.button
            onClick={() => setActiveCategory(null)}
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
            className={`px-4 py-2 rounded-full text-sm transition-all duration-300 ${
              activeCategory === null
                ? "bg-gradient-to-r from-purple-600 to-blue-600 text-white shadow-lg"
                : "bg-white/70 dark:bg-gray-900/70 text-foreground border border-purple-200 dark:border-purple-800 hover:border-purple-400"
            }`}
            style={{ fontWeight: 500 }}
          >
            All Skills
          </motion.button>
          {skillCategories.map((cat) => (
            <motion.button
              key={cat.id}
              onClick={() => setActiveCategory(activeCategory === cat.id ? null : cat.id)}
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
              className={`flex items-center gap-1.5 px-4 py-2 rounded-full text-sm transition-all duration-300 ${
                activeCategory === cat.id
                  ? `bg-gradient-to-r ${cat.gradient} text-white shadow-lg`
                  : "bg-white/70 dark:bg-gray-900/70 text-foreground border border-purple-200 dark:border-purple-800 hover:border-purple-400"
              }`}
              style={{ fontWeight: 500 }}
            >
              <cat.icon className="w-3.5 h-3.5" />
              {cat.title}
            </motion.button>
          ))}
        </div>

        {/* Skills grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 max-w-7xl mx-auto">
          <AnimatePresence mode="popLayout">
            {skillCategories
              .filter(cat => activeCategory === null || cat.id === activeCategory)
              .map((category, categoryIndex) => (
                <motion.div
                  key={category.id}
                  layout
                  initial={{ opacity: 0, scale: 0.9 }}
                  animate={{ opacity: 1, scale: 1 }}
                  exit={{ opacity: 0, scale: 0.9 }}
                  transition={{ duration: 0.4, delay: categoryIndex * 0.1 }}
                  className={`group ${activeCategory === category.id ? "md:col-span-2 lg:col-span-3" : ""}`}
                >
                  <div className="h-full bg-white/80 dark:bg-gray-950/80 backdrop-blur-xl rounded-3xl p-7 border border-purple-200/60 dark:border-purple-800/60 shadow-lg hover:shadow-xl hover:-translate-y-1 transition-all duration-300">
                    {/* Header */}
                    <div className="flex items-center gap-4 mb-6">
                      <motion.div
                        whileHover={{ rotate: 10, scale: 1.1 }}
                        className={`w-14 h-14 bg-gradient-to-br ${category.gradient} rounded-2xl flex items-center justify-center shadow-lg flex-shrink-0`}
                      >
                        <category.icon className="w-7 h-7 text-white" />
                      </motion.div>
                      <div>
                        <h3 className="text-foreground" style={{ fontWeight: 600 }}>{category.title}</h3>
                        <p className="text-xs text-muted-foreground">{category.skills.length} skills · {category.description}</p>
                      </div>
                      <div className={`ml-auto px-3 py-1 bg-gradient-to-r ${category.gradient} rounded-full text-white text-xs`} style={{ fontWeight: 600 }}>
                        {Math.round(category.skills.reduce((a, s) => a + s.level, 0) / category.skills.length)}% avg
                      </div>
                    </div>

                    {/* Skills */}
                    <div className={`space-y-4 ${activeCategory === category.id ? "grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-x-8 space-y-0 gap-y-4" : ""}`}>
                      {category.skills.map((skill, skillIndex) => (
                        <SkillBar
                          key={skill.name}
                          skill={skill}
                          gradient={category.gradient}
                          delay={categoryIndex * 0.1 + skillIndex * 0.06}
                        />
                      ))}
                    </div>

                    {/* Tag cloud for skills */}
                    <div className="mt-5 pt-5 border-t border-purple-100 dark:border-purple-900/40">
                      <div className="flex flex-wrap gap-1.5">
                        {category.skills.map((skill) => (
                          <motion.span
                            key={skill.name}
                            whileHover={{ scale: 1.08, y: -1 }}
                            className={`px-2.5 py-1 bg-gradient-to-r ${category.gradient} bg-opacity-10 text-${category.color}-700 dark:text-${category.color}-300 rounded-full text-xs border border-${category.color}-200 dark:border-${category.color}-800/60 cursor-default`}
                            style={{
                              background: `linear-gradient(135deg, rgba(108,99,255,0.08), rgba(59,130,246,0.08))`,
                              fontWeight: 500,
                            }}
                          >
                            {skill.icon} {skill.name}
                          </motion.span>
                        ))}
                      </div>
                    </div>
                  </div>
                </motion.div>
              ))}
          </AnimatePresence>
        </div>

        {/* Total skills count */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6, delay: 0.4 }}
          className="text-center mt-12"
        >
          <div className="inline-flex items-center gap-3 px-6 py-3 bg-white/70 dark:bg-gray-900/70 backdrop-blur-xl rounded-full border border-purple-200 dark:border-purple-800 shadow-lg">
            <span className="text-muted-foreground text-sm">Proficient in</span>
            <span
              className="text-2xl bg-gradient-to-r from-purple-600 to-blue-600 bg-clip-text text-transparent"
              style={{ fontWeight: 700 }}
            >
              {skillCategories.reduce((a, c) => a + c.skills.length, 0)}+
            </span>
            <span className="text-muted-foreground text-sm">technologies across AI/ML</span>
          </div>
        </motion.div>
      </div>
    </section>
  );
}
