import { useState } from "react";
import { motion } from "motion/react";
import { Award, CheckCircle, ExternalLink, RotateCcw } from "lucide-react";

const certifications = [
  {
    title: "Google AI-ML Virtual Internship",
    issuer: "Google",
    description: "Completed intensive AI/ML virtual internship covering Google's AI tools, machine learning fundamentals, and real-world applications.",
    icon: "🎓",
    color: "from-blue-500 to-cyan-500",
    year: "2024",
    skills: ["Python", "ML Basics", "TensorFlow", "Data Analysis"],
  },
  {
    title: "AI for Youth Workshop",
    issuer: "AI Education Program",
    description: "Completed comprehensive AI for Youth program covering foundational AI concepts, ethics, and hands-on projects.",
    icon: "🤖",
    color: "from-purple-500 to-pink-500",
    year: "2024",
    skills: ["AI Fundamentals", "Ethics in AI", "Project Building"],
  },
  {
    title: "EduSkill ZScaler Virtual Internship",
    issuer: "EduSkill & ZScaler",
    description: "Completed cybersecurity-focused virtual internship covering network security, threat analysis, and zero-trust principles.",
    icon: "🔒",
    color: "from-indigo-500 to-blue-500",
    year: "2023",
    skills: ["Network Security", "Zero Trust", "Threat Analysis"],
  },
  {
    title: "Machine Learning Certification",
    issuer: "To Be Updated",
    description: "Certification placeholder — will be updated with actual ML certification details.",
    icon: "📜",
    color: "from-emerald-500 to-teal-500",
    year: "2025",
    skills: ["ML Algorithms", "Model Training", "Evaluation"],
  },
];

function CertCard({ cert, index }: { cert: typeof certifications[0]; index: number }) {
  const [flipped, setFlipped] = useState(false);

  return (
    <motion.div
      initial={{ opacity: 0, y: 50 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true }}
      transition={{ delay: index * 0.15, duration: 0.6 }}
      className="cursor-pointer"
      style={{ perspective: 1200 }}
      onClick={() => setFlipped(!flipped)}
    >
      <motion.div
        animate={{ rotateY: flipped ? 180 : 0 }}
        transition={{ duration: 0.6, type: "spring", damping: 20 }}
        style={{ transformStyle: "preserve-3d" }}
        className="relative w-full h-72"
      >
        {/* Front */}
        <div
          style={{ backfaceVisibility: "hidden", WebkitBackfaceVisibility: "hidden" }}
          className="absolute inset-0"
        >
          <div className="relative h-full group">
            <div className={`absolute -inset-0.5 bg-gradient-to-r ${cert.color} rounded-3xl blur opacity-0 group-hover:opacity-40 transition-opacity duration-300`} />
            <div className="relative h-full bg-white/85 dark:bg-gray-950/85 backdrop-blur-xl rounded-3xl p-7 border border-purple-200/60 dark:border-purple-800/60 shadow-xl hover:shadow-2xl transition-shadow overflow-hidden">
              <div className={`absolute top-0 left-0 right-0 h-1 bg-gradient-to-r ${cert.color}`} />

              <div className="absolute top-5 right-5 flex items-center gap-2">
                <span className={`px-2.5 py-1 bg-gradient-to-r ${cert.color} text-white rounded-full text-xs shadow-md`} style={{ fontWeight: 600 }}>
                  {cert.year}
                </span>
                <RotateCcw className="w-3.5 h-3.5 text-muted-foreground opacity-60" />
              </div>

              <motion.div
                whileHover={{ scale: 1.1, rotate: 5 }}
                className="text-5xl mb-5 mt-1 inline-block"
              >
                {cert.icon}
              </motion.div>

              <h3 className="text-foreground mb-1.5 pr-14" style={{ fontWeight: 600 }}>{cert.title}</h3>
              <p className="text-sm text-muted-foreground mb-5">{cert.issuer}</p>

              <div className={`inline-flex items-center gap-2 px-3 py-2 bg-gradient-to-r ${cert.color} bg-opacity-10 rounded-xl border border-current`}
                style={{ background: "transparent" }}
              >
                <CheckCircle className="w-4 h-4 text-green-500" />
                <span className="text-sm text-foreground" style={{ fontWeight: 500 }}>Certified</span>
              </div>

              <p className="absolute bottom-5 left-7 text-xs text-muted-foreground/60">Click to see details →</p>
            </div>
          </div>
        </div>

        {/* Back */}
        <div
          style={{ backfaceVisibility: "hidden", WebkitBackfaceVisibility: "hidden", transform: "rotateY(180deg)" }}
          className="absolute inset-0"
        >
          <div className={`h-full bg-gradient-to-br ${cert.color} rounded-3xl p-7 shadow-xl`}>
            <h3 className="text-white mb-2" style={{ fontWeight: 700 }}>{cert.title}</h3>
            <p className="text-white/80 text-xs mb-5 leading-relaxed">{cert.description}</p>

            <p className="text-white/70 text-xs mb-2" style={{ fontWeight: 600 }}>Skills Covered:</p>
            <div className="flex flex-wrap gap-2 mb-5">
              {cert.skills.map((skill, i) => (
                <span key={i} className="px-2.5 py-1 bg-white/20 text-white rounded-full text-xs backdrop-blur-sm">
                  {skill}
                </span>
              ))}
            </div>

            <div className="flex items-center gap-2 text-white/70 text-xs">
              <Award className="w-3.5 h-3.5" />
              <span>Issued by {cert.issuer} · {cert.year}</span>
            </div>

            <p className="absolute bottom-5 left-7 text-xs text-white/50">Click to flip back ↩</p>
          </div>
        </div>
      </motion.div>
    </motion.div>
  );
}

export function Certifications() {
  return (
    <section id="certifications" className="py-24 relative overflow-hidden">
      <div className="absolute inset-0 bg-gradient-to-b from-transparent via-blue-50/25 to-transparent dark:via-blue-950/8" />

      <div className="container mx-auto px-4 relative z-10">
        <motion.div
          initial={{ opacity: 0, y: 50 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.8 }}
          className="text-center mb-16"
        >
          <motion.div
            initial={{ scale: 0 }}
            whileInView={{ scale: 1 }}
            viewport={{ once: true }}
            className="inline-flex items-center gap-2 px-4 py-2 bg-gradient-to-r from-blue-100 to-purple-100 dark:from-blue-900/40 dark:to-purple-900/40 rounded-full text-blue-700 dark:text-blue-300 text-sm border border-blue-200 dark:border-blue-700 mb-4"
          >
            <Award className="w-4 h-4" />
            Credentials
          </motion.div>
          <h2
            className="text-5xl lg:text-6xl mb-4 bg-gradient-to-r from-blue-600 via-purple-600 to-pink-600 bg-clip-text text-transparent"
            style={{ fontWeight: 700 }}
          >
            Certifications
          </h2>
          <p className="text-muted-foreground max-w-2xl mx-auto">
            Continuous learning through recognized programs and internships.{" "}
            <span className="text-purple-600 dark:text-purple-400" style={{ fontWeight: 500 }}>Click cards to flip!</span>
          </p>
        </motion.div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 max-w-7xl mx-auto">
          {certifications.map((cert, index) => (
            <CertCard key={index} cert={cert} index={index} />
          ))}
        </div>
      </div>
    </section>
  );
}
