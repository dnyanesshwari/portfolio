import { useState } from "react";
import { motion, AnimatePresence } from "motion/react";
import { Github, ExternalLink, X, ChevronRight, Layers, Brain, Cpu, Database, Globe, Shield } from "lucide-react";

type Project = {
  title: string;
  description: string;
  longDescription: string;
  tags: string[];
  category: string;
  gradient: string;
  githubUrl: string;
  features: string[];
  techStack: string[];
  impact: string;
  emoji: string;
};

const projects: Project[] = [
  {
    title: "DeepFake Audio Detection",
    description: "Deep Learning system to detect AI-generated fake audio using multiple model architectures.",
    longDescription: "Built a comprehensive deepfake audio detection system that employs multiple state-of-the-art deep learning architectures. Implemented end-to-end pipeline from raw audio preprocessing to model inference, with detailed model comparison and performance evaluation.",
    tags: ["Deep Learning", "Audio AI", "CNN", "Signal Processing"],
    category: "Deep Learning",
    gradient: "from-violet-600 to-purple-600",
    githubUrl: "https://github.com/dnyanesshwari",
    features: ["Audio preprocessing pipeline", "MFCC feature extraction", "Multi-model comparison", "Performance evaluation dashboard", "Real-time detection"],
    techStack: ["Python", "TensorFlow", "PyTorch", "LibROSA", "NumPy", "Matplotlib"],
    impact: "Helps identify AI-generated fake audio content, contributing to digital media integrity.",
    emoji: "🎙️",
  },
  {
    title: "Festival-Aware Dairy Forecasting",
    description: "AI-powered demand forecasting system for dairy cooperatives with festival-awareness.",
    longDescription: "Developed an intelligent forecasting platform for dairy cooperatives that accounts for festival seasons and cultural events. Combines multiple forecasting models including XGBoost, SARIMAX, and Prophet to optimize production and minimize waste.",
    tags: ["Machine Learning", "Time Series", "FastAPI", "PostgreSQL"],
    category: "Machine Learning",
    gradient: "from-blue-600 to-cyan-500",
    githubUrl: "https://github.com/dnyanesshwari",
    features: ["Festival-aware forecasting", "Multi-model ensemble", "Interactive dashboard", "Production optimization", "Data visualization"],
    techStack: ["Python", "XGBoost", "SARIMAX", "Prophet", "FastAPI", "PostgreSQL", "Pandas"],
    impact: "Reduces dairy wastage by up to 30% through intelligent demand prediction.",
    emoji: "🥛",
  },
  {
    title: "AASHA AI Chatbot",
    description: "Women's safety AI assistant with YouTube integration and LLM-powered responses.",
    longDescription: "AASHA (AI-Powered Safety & Support Hub for All) is a comprehensive women's safety chatbot. Features FastAPI backend, user authentication, conversation history, and intelligent AI-powered responses using advanced LLMs with prompt engineering.",
    tags: ["LLM", "FastAPI", "NLP", "SQLite"],
    category: "Generative AI",
    gradient: "from-pink-600 to-rose-500",
    githubUrl: "https://github.com/dnyanesshwari",
    features: ["FastAPI backend", "User authentication", "Conversation history", "YouTube integration", "Prompt engineering", "LLM integration"],
    techStack: ["Python", "FastAPI", "LangChain", "SQLite", "Streamlit", "OpenAI API"],
    impact: "Empowers women with accessible safety resources and intelligent support 24/7.",
    emoji: "🛡️",
  },
  {
    title: "Finance AI Assistant",
    description: "AI-powered financial advisor using Generative AI for intelligent financial guidance.",
    longDescription: "An intelligent financial assistant powered by large language models that provides personalized financial guidance. Uses advanced prompt engineering to deliver contextually relevant financial advice and analysis.",
    tags: ["Generative AI", "LLMs", "FinTech", "Python"],
    category: "Generative AI",
    gradient: "from-emerald-600 to-teal-500",
    githubUrl: "https://github.com/dnyanesshwari",
    features: ["Personalized financial advice", "LLM-powered responses", "Interactive Q&A", "Financial analysis", "User-friendly interface"],
    techStack: ["Python", "LangChain", "OpenAI", "Streamlit", "Pandas"],
    impact: "Democratizes access to financial expertise for individuals and small businesses.",
    emoji: "💰",
  },
  {
    title: "StratArena (MARL)",
    description: "Multi-Agent Reinforcement Learning environment inspired by OpenAI Gym with competitive AI agents.",
    longDescription: "StratArena is a sophisticated multi-agent reinforcement learning environment that simulates competitive economic scenarios. Agents employ Theory-of-Mind reasoning to model opponent strategies and make adaptive decisions in auction simulations.",
    tags: ["Reinforcement Learning", "Multi-Agent", "PyTorch", "Game Theory"],
    category: "Reinforcement Learning",
    gradient: "from-orange-600 to-red-500",
    githubUrl: "https://github.com/dnyanesshwari",
    features: ["Theory-of-Mind reasoning", "Auction simulation", "Adaptive strategies", "Competitive AI agents", "Custom gym environment"],
    techStack: ["Python", "PyTorch", "OpenAI Gym", "NumPy", "Matplotlib"],
    impact: "Advances multi-agent AI research with practical game-theoretic applications.",
    emoji: "🤖",
  },
  {
    title: "StartupSarthi CA Agent",
    description: "AI CA Agent for startups using IBM watsonx and Gemini AI — 2nd Prize IndiaAI Hackathon.",
    longDescription: "Developed at the IndiaAI Impact GenAI Hackathon, StartupSarthi is an intelligent CA (Chartered Accountant) agent designed to assist startups with business guidance. Built with IBM watsonx and Google Gemini AI, it won 2nd Prize nationally.",
    tags: ["IBM watsonx", "Gemini AI", "GenAI", "Startups"],
    category: "Generative AI",
    gradient: "from-amber-600 to-yellow-500",
    githubUrl: "https://github.com/dnyanesshwari",
    features: ["Business compliance guidance", "Tax advisory", "IBM watsonx integration", "Gemini AI responses", "Startup-focused advice"],
    techStack: ["Python", "IBM watsonx", "Google Gemini", "FastAPI", "Streamlit"],
    impact: "Won 2nd Prize at IndiaAI Impact GenAI Hackathon — helps startups navigate complex business regulations.",
    emoji: "🏆",
  },
  {
    title: "Chillbot",
    description: "AI chatbot for student mental health support and stress management guidance.",
    longDescription: "Chillbot is an empathetic AI assistant specifically designed for students experiencing academic stress and mental health challenges. Provides evidence-based coping strategies, mindfulness guidance, and emotional support.",
    tags: ["NLP", "Chatbot", "Mental Health", "Streamlit"],
    category: "Machine Learning",
    gradient: "from-sky-600 to-blue-500",
    githubUrl: "https://github.com/dnyanesshwari",
    features: ["Empathetic conversations", "Stress management tips", "Mindfulness exercises", "Academic guidance", "Anonymous support"],
    techStack: ["Python", "Streamlit", "LangChain", "NLP", "Flask"],
    impact: "Supports student wellbeing with accessible, stigma-free mental health resources.",
    emoji: "🧘",
  },
  {
    title: "Tarini — Women Safety Bot",
    description: "WhatsApp women safety chatbot integrated with Twilio for emergency assistance.",
    longDescription: "Tarini is a WhatsApp-based safety assistant for women, built with Twilio integration. Provides instant access to emergency contacts, safety resources, and real-time support through a familiar messaging platform.",
    tags: ["Twilio", "WhatsApp", "Safety", "NLP"],
    category: "Machine Learning",
    gradient: "from-fuchsia-600 to-purple-500",
    githubUrl: "https://github.com/dnyanesshwari",
    features: ["WhatsApp integration", "Emergency contacts", "Safety resources", "Real-time support", "Twilio SMS alerts"],
    techStack: ["Python", "Twilio", "Flask", "NLP", "SQLite"],
    impact: "Provides safety support via WhatsApp — accessible to women without technical barriers.",
    emoji: "📱",
  },
];

const categories = ["All", "Deep Learning", "Machine Learning", "Generative AI", "Reinforcement Learning"];

function ProjectModal({ project, onClose }: { project: Project; onClose: () => void }) {
  return (
    <AnimatePresence>
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        exit={{ opacity: 0 }}
        className="fixed inset-0 z-[200] flex items-center justify-center p-4"
        onClick={onClose}
      >
        <div className="absolute inset-0 bg-black/60 backdrop-blur-sm" />
        <motion.div
          initial={{ opacity: 0, scale: 0.9, y: 20 }}
          animate={{ opacity: 1, scale: 1, y: 0 }}
          exit={{ opacity: 0, scale: 0.9, y: 20 }}
          transition={{ type: "spring", damping: 25 }}
          className="relative bg-white dark:bg-gray-950 rounded-3xl shadow-2xl max-w-2xl w-full max-h-[90vh] overflow-y-auto border border-purple-200 dark:border-purple-800"
          onClick={(e) => e.stopPropagation()}
        >
          {/* Header with gradient */}
          <div className={`relative bg-gradient-to-r ${project.gradient} p-8 rounded-t-3xl`}>
            <button
              onClick={onClose}
              className="absolute top-4 right-4 p-2 bg-white/20 hover:bg-white/30 rounded-full transition-colors backdrop-blur-sm"
            >
              <X className="w-5 h-5 text-white" />
            </button>
            <div className="text-4xl mb-3">{project.emoji}</div>
            <h3 className="text-2xl text-white mb-2" style={{ fontWeight: 700 }}>{project.title}</h3>
            <div className="flex flex-wrap gap-2">
              {project.tags.map((tag, i) => (
                <span key={i} className="px-3 py-1 bg-white/20 text-white rounded-full text-xs backdrop-blur-sm">
                  {tag}
                </span>
              ))}
            </div>
          </div>

          <div className="p-8 space-y-6">
            {/* Description */}
            <div>
              <h4 className="text-foreground mb-2" style={{ fontWeight: 600 }}>About</h4>
              <p className="text-muted-foreground leading-relaxed">{project.longDescription}</p>
            </div>

            {/* Features */}
            <div>
              <h4 className="text-foreground mb-3" style={{ fontWeight: 600 }}>Key Features</h4>
              <div className="grid grid-cols-1 gap-2">
                {project.features.map((feature, i) => (
                  <motion.div
                    key={i}
                    initial={{ opacity: 0, x: -10 }}
                    animate={{ opacity: 1, x: 0 }}
                    transition={{ delay: i * 0.05 }}
                    className="flex items-center gap-2"
                  >
                    <ChevronRight className="w-4 h-4 text-purple-500 flex-shrink-0" />
                    <span className="text-sm text-foreground">{feature}</span>
                  </motion.div>
                ))}
              </div>
            </div>

            {/* Tech Stack */}
            <div>
              <h4 className="text-foreground mb-3" style={{ fontWeight: 600 }}>Tech Stack</h4>
              <div className="flex flex-wrap gap-2">
                {project.techStack.map((tech, i) => (
                  <span
                    key={i}
                    className="px-3 py-1.5 bg-purple-50 dark:bg-purple-900/30 text-purple-700 dark:text-purple-300 rounded-lg text-xs border border-purple-200 dark:border-purple-700"
                    style={{ fontWeight: 500 }}
                  >
                    {tech}
                  </span>
                ))}
              </div>
            </div>

            {/* Impact */}
            <div className="p-4 bg-gradient-to-r from-purple-50 to-blue-50 dark:from-purple-950/30 dark:to-blue-950/30 rounded-2xl border border-purple-200 dark:border-purple-800">
              <h4 className="text-purple-700 dark:text-purple-300 mb-1 text-sm" style={{ fontWeight: 600 }}>Impact</h4>
              <p className="text-sm text-foreground">{project.impact}</p>
            </div>

            {/* CTA */}
            <div className="flex gap-3">
              <motion.a
                href={project.githubUrl}
                target="_blank"
                rel="noopener noreferrer"
                whileHover={{ scale: 1.03 }}
                whileTap={{ scale: 0.97 }}
                className={`flex-1 flex items-center justify-center gap-2 py-3 bg-gradient-to-r ${project.gradient} text-white rounded-2xl shadow-lg`}
                style={{ fontWeight: 600 }}
              >
                <Github className="w-5 h-5" />
                View on GitHub
              </motion.a>
            </div>
          </div>
        </motion.div>
      </motion.div>
    </AnimatePresence>
  );
}

export function Projects() {
  const [activeCategory, setActiveCategory] = useState("All");
  const [selectedProject, setSelectedProject] = useState<Project | null>(null);
  const [hoveredIndex, setHoveredIndex] = useState<number | null>(null);

  const filtered = activeCategory === "All"
    ? projects
    : projects.filter(p => p.category === activeCategory);

  return (
    <section id="projects" className="py-24 relative overflow-hidden">
      <div className="absolute inset-0 bg-gradient-to-b from-purple-50/50 via-blue-50/30 to-pink-50/50 dark:from-purple-950/20 dark:via-blue-950/10 dark:to-pink-950/20" />

      <motion.div
        animate={{ rotate: 360 }}
        transition={{ duration: 40, repeat: Infinity, ease: "linear" }}
        className="absolute top-20 right-10 w-40 h-40 border-2 border-purple-200 dark:border-purple-800 rounded-full opacity-15"
      />
      <motion.div
        animate={{ rotate: -360 }}
        transition={{ duration: 35, repeat: Infinity, ease: "linear" }}
        className="absolute bottom-20 left-10 w-28 h-28 border-2 border-blue-200 dark:border-blue-800 rounded-full opacity-15"
      />

      <div className="container mx-auto px-4 relative z-10">
        {/* Section header */}
        <motion.div
          initial={{ opacity: 0, y: 50 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.8 }}
          className="text-center mb-12"
        >
          <motion.div
            initial={{ scale: 0 }}
            whileInView={{ scale: 1 }}
            viewport={{ once: true }}
            transition={{ duration: 0.5 }}
            className="inline-flex items-center gap-2 px-4 py-2 bg-gradient-to-r from-purple-100 to-blue-100 dark:from-purple-900/40 dark:to-blue-900/40 rounded-full text-purple-700 dark:text-purple-300 text-sm border border-purple-200 dark:border-purple-700 mb-4"
          >
            <Layers className="w-4 h-4" />
            My Work
          </motion.div>
          <h2
            className="text-5xl lg:text-6xl mb-4 bg-gradient-to-r from-purple-600 via-blue-600 to-pink-600 bg-clip-text text-transparent"
            style={{ fontWeight: 700 }}
          >
            Featured Projects
          </h2>
          <p className="text-muted-foreground max-w-2xl mx-auto">
            Explore my portfolio of AI-driven projects — from deep learning and reinforcement learning to generative AI and social impact applications.
          </p>
        </motion.div>

        {/* Filter tabs */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6, delay: 0.2 }}
          className="flex flex-wrap justify-center gap-2 mb-12"
        >
          {categories.map((cat) => (
            <motion.button
              key={cat}
              onClick={() => setActiveCategory(cat)}
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
              className={`px-5 py-2.5 rounded-full text-sm transition-all duration-300 ${
                activeCategory === cat
                  ? "bg-gradient-to-r from-purple-600 to-blue-600 text-white shadow-lg shadow-purple-500/30"
                  : "bg-white/70 dark:bg-gray-900/70 text-foreground border border-purple-200 dark:border-purple-800 hover:border-purple-400"
              }`}
              style={{ fontWeight: activeCategory === cat ? 600 : 500 }}
            >
              {cat}
              {cat !== "All" && (
                <span className={`ml-2 px-1.5 py-0.5 rounded-full text-xs ${
                  activeCategory === cat ? "bg-white/20" : "bg-purple-100 dark:bg-purple-900/40 text-purple-600 dark:text-purple-400"
                }`}>
                  {projects.filter(p => p.category === cat).length}
                </span>
              )}
            </motion.button>
          ))}
        </motion.div>

        {/* Projects grid */}
        <motion.div layout className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6 max-w-8xl mx-auto">
          <AnimatePresence mode="popLayout">
            {filtered.map((project, index) => (
              <motion.div
                key={project.title}
                layout
                initial={{ opacity: 0, scale: 0.9 }}
                animate={{ opacity: 1, scale: 1 }}
                exit={{ opacity: 0, scale: 0.9 }}
                transition={{ duration: 0.4, delay: index * 0.05 }}
                onHoverStart={() => setHoveredIndex(index)}
                onHoverEnd={() => setHoveredIndex(null)}
                onClick={() => setSelectedProject(project)}
                className="group cursor-pointer"
              >
                <div className="relative h-full bg-white/80 dark:bg-gray-950/80 backdrop-blur-xl rounded-3xl overflow-hidden border border-purple-200/60 dark:border-purple-800/60 shadow-lg hover:shadow-2xl hover:shadow-purple-500/20 transition-all duration-500 hover:-translate-y-2">
                  {/* Gradient top bar */}
                  <div className={`h-1.5 bg-gradient-to-r ${project.gradient}`} />

                  {/* Card glow on hover */}
                  <div className={`absolute -inset-0.5 bg-gradient-to-r ${project.gradient} rounded-3xl blur opacity-0 group-hover:opacity-20 transition-opacity duration-300 -z-10`} />

                  <div className="p-6">
                    {/* Emoji + category */}
                    <div className="flex items-start justify-between mb-4">
                      <motion.div
                        animate={hoveredIndex === index ? { rotate: [0, -10, 10, 0], scale: [1, 1.1, 1] } : {}}
                        transition={{ duration: 0.4 }}
                        className="text-3xl"
                      >
                        {project.emoji}
                      </motion.div>
                      <span className="px-2.5 py-1 bg-purple-50 dark:bg-purple-900/30 text-purple-600 dark:text-purple-400 rounded-full text-xs border border-purple-200 dark:border-purple-800" style={{ fontWeight: 500 }}>
                        {project.category}
                      </span>
                    </div>

                    <h3
                      className="text-foreground mb-2 group-hover:text-purple-600 dark:group-hover:text-purple-400 transition-colors"
                      style={{ fontWeight: 600 }}
                    >
                      {project.title}
                    </h3>

                    <p className="text-sm text-muted-foreground mb-4 line-clamp-2 leading-relaxed">
                      {project.description}
                    </p>

                    {/* Tags */}
                    <div className="flex flex-wrap gap-1.5 mb-5">
                      {project.tags.slice(0, 3).map((tag, i) => (
                        <span
                          key={i}
                          className="px-2.5 py-1 bg-gradient-to-r from-purple-50 to-blue-50 dark:from-purple-900/20 dark:to-blue-900/20 text-purple-700 dark:text-purple-300 rounded-full text-xs border border-purple-200/60 dark:border-purple-700/60"
                        >
                          {tag}
                        </span>
                      ))}
                    </div>

                    {/* Footer */}
                    <div className="flex items-center justify-between">
                      <motion.span
                        className={`text-sm bg-gradient-to-r ${project.gradient} bg-clip-text text-transparent`}
                        style={{ fontWeight: 600 }}
                        animate={hoveredIndex === index ? { x: [0, 3, 0] } : {}}
                        transition={{ duration: 0.4, repeat: hoveredIndex === index ? Infinity : 0 }}
                      >
                        View details →
                      </motion.span>
                      <a
                        href={project.githubUrl}
                        target="_blank"
                        rel="noopener noreferrer"
                        onClick={(e) => e.stopPropagation()}
                        className="p-2 bg-gray-100 dark:bg-gray-800 rounded-full hover:bg-purple-100 dark:hover:bg-purple-900/40 transition-colors"
                      >
                        <Github className="w-4 h-4 text-muted-foreground" />
                      </a>
                    </div>
                  </div>
                </div>
              </motion.div>
            ))}
          </AnimatePresence>
        </motion.div>

        {/* GitHub CTA */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.7, delay: 0.3 }}
          className="text-center mt-16"
        >
          <motion.a
            href="https://github.com/dnyanesshwari"
            target="_blank"
            rel="noopener noreferrer"
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.97 }}
            className="inline-flex items-center gap-3 px-8 py-4 bg-gray-900 dark:bg-white text-white dark:text-gray-900 rounded-full shadow-xl hover:shadow-2xl transition-all duration-300"
            style={{ fontWeight: 600 }}
          >
            <Github className="w-5 h-5" />
            See all projects on GitHub
          </motion.a>
        </motion.div>
      </div>

      {/* Project Modal */}
      {selectedProject && (
        <ProjectModal project={selectedProject} onClose={() => setSelectedProject(null)} />
      )}
    </section>
  );
}
