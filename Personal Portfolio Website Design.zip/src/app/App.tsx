import { useEffect, useState, useRef } from "react";
import { AnimatedBackground } from "./components/AnimatedBackground";
import { Navbar } from "./components/Navbar";
import { Hero } from "./components/Hero";
import { About } from "./components/About";
import { Projects } from "./components/Projects";
import { Education } from "./components/Education";
import { Skills } from "./components/Skills";
import { Certifications } from "./components/Certifications";
import { Achievements } from "./components/Achievements";
import { GitHubStats } from "./components/GitHubStats";
import { LearningJourney } from "./components/LearningJourney";
import { Contact } from "./components/Contact";
import { Footer } from "./components/Footer";

function ScrollProgressBar() {
  const [progress, setProgress] = useState(0);

  useEffect(() => {
    const handleScroll = () => {
      const total = document.documentElement.scrollHeight - window.innerHeight;
      const current = window.scrollY;
      setProgress(total > 0 ? (current / total) * 100 : 0);
    };
    window.addEventListener("scroll", handleScroll, { passive: true });
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  return (
    <div className="fixed top-0 left-0 right-0 z-[100] h-1 bg-transparent">
      <div
        className="h-full bg-gradient-to-r from-purple-600 via-blue-500 to-pink-500 transition-all duration-100 ease-out shadow-lg"
        style={{ width: `${progress}%` }}
      />
    </div>
  );
}

function CustomCursor() {
  const cursorRef = useRef<HTMLDivElement>(null);
  const dotRef = useRef<HTMLDivElement>(null);
  const [isVisible, setIsVisible] = useState(false);
  const [isClicking, setIsClicking] = useState(false);
  const [isHovering, setIsHovering] = useState(false);
  const pos = useRef({ x: 0, y: 0 });
  const cursorPos = useRef({ x: 0, y: 0 });
  const rafRef = useRef<number>(0);

  useEffect(() => {
    const handleMove = (e: MouseEvent) => {
      pos.current = { x: e.clientX, y: e.clientY };
      setIsVisible(true);
      if (dotRef.current) {
        dotRef.current.style.left = `${e.clientX}px`;
        dotRef.current.style.top = `${e.clientY}px`;
      }
    };
    const handleDown = () => setIsClicking(true);
    const handleUp = () => setIsClicking(false);
    const handleLeave = () => setIsVisible(false);

    const checkHover = (e: MouseEvent) => {
      const target = e.target as Element;
      setIsHovering(!!target.closest("a, button, [role='button'], .hoverable"));
    };

    const animate = () => {
      if (cursorRef.current) {
        cursorPos.current.x += (pos.current.x - cursorPos.current.x) * 0.12;
        cursorPos.current.y += (pos.current.y - cursorPos.current.y) * 0.12;
        cursorRef.current.style.left = `${cursorPos.current.x}px`;
        cursorRef.current.style.top = `${cursorPos.current.y}px`;
      }
      rafRef.current = requestAnimationFrame(animate);
    };

    window.addEventListener("mousemove", handleMove);
    window.addEventListener("mousemove", checkHover);
    window.addEventListener("mousedown", handleDown);
    window.addEventListener("mouseup", handleUp);
    document.documentElement.addEventListener("mouseleave", handleLeave);
    rafRef.current = requestAnimationFrame(animate);

    return () => {
      window.removeEventListener("mousemove", handleMove);
      window.removeEventListener("mousemove", checkHover);
      window.removeEventListener("mousedown", handleDown);
      window.removeEventListener("mouseup", handleUp);
      document.documentElement.removeEventListener("mouseleave", handleLeave);
      cancelAnimationFrame(rafRef.current);
    };
  }, []);

  if (typeof window !== "undefined" && window.matchMedia("(pointer: coarse)").matches) return null;

  return (
    <>
      <div
        ref={cursorRef}
        className="fixed pointer-events-none z-[9999] -translate-x-1/2 -translate-y-1/2 rounded-full border-2 border-purple-500/60 transition-all duration-200"
        style={{
          width: isHovering ? 44 : isClicking ? 16 : 32,
          height: isHovering ? 44 : isClicking ? 16 : 32,
          opacity: isVisible ? 1 : 0,
          background: isHovering ? "rgba(108,99,255,0.12)" : "transparent",
          boxShadow: isHovering ? "0 0 20px rgba(108,99,255,0.4)" : "none",
        }}
      />
      <div
        ref={dotRef}
        className="fixed pointer-events-none z-[9999] -translate-x-1/2 -translate-y-1/2 w-2 h-2 rounded-full bg-purple-500"
        style={{ opacity: isVisible ? 1 : 0 }}
      />
    </>
  );
}

export default function App() {
  return (
    <div className="relative min-h-screen cursor-none">
      <CustomCursor />
      <ScrollProgressBar />
      <AnimatedBackground />
      <Navbar />
      <main className="relative z-10">
        <Hero />
        <About />
        <Projects />
        <Skills />
        <Education />
        <Achievements />
        <GitHubStats />
        <Certifications />
        <LearningJourney />
        <Contact />
      </main>
      <Footer />
    </div>
  );
}
