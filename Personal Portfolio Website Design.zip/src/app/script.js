// ==========================================
// PORTFOLIO JAVASCRIPT - Pure Vanilla JS
// ==========================================

// ==========================================
// 1. THEME TOGGLE
// ==========================================
const themeToggle = document.getElementById('theme-toggle');
const html = document.documentElement;

// Load saved theme
const savedTheme = localStorage.getItem('theme');
if (savedTheme === 'dark') {
    html.classList.add('dark');
}

// Theme toggle handler
if (themeToggle) {
    themeToggle.addEventListener('click', () => {
        html.classList.toggle('dark');
        const isDark = html.classList.contains('dark');
        localStorage.setItem('theme', isDark ? 'dark' : 'light');
    });
}

// ==========================================
// 2. MOBILE MENU
// ==========================================
const mobileMenuBtn = document.getElementById('mobile-menu-btn');
const mobileMenu = document.getElementById('mobile-menu');
const mobileMenuBackdrop = document.getElementById('mobile-menu-backdrop');

if (mobileMenuBtn) {
    mobileMenuBtn.addEventListener('click', () => {
        mobileMenuBtn.classList.toggle('active');
        mobileMenu.classList.toggle('active');
        mobileMenuBackdrop.classList.toggle('active');
    });
}

// Close mobile menu when clicking backdrop
if (mobileMenuBackdrop) {
    mobileMenuBackdrop.addEventListener('click', () => {
        mobileMenuBtn.classList.remove('active');
        mobileMenu.classList.remove('active');
        mobileMenuBackdrop.classList.remove('active');
    });
}

// Close mobile menu when clicking a link
const mobileLinks = document.querySelectorAll('.mobile-link');
mobileLinks.forEach(link => {
    link.addEventListener('click', () => {
        mobileMenuBtn.classList.remove('active');
        mobileMenu.classList.remove('active');
        mobileMenuBackdrop.classList.remove('active');
    });
});

// Close mobile menu on window resize
window.addEventListener('resize', () => {
    if (window.innerWidth >= 768) {
        mobileMenuBtn.classList.remove('active');
        mobileMenu.classList.remove('active');
        mobileMenuBackdrop.classList.remove('active');
    }
});

// ==========================================
// 3. SMOOTH SCROLLING FOR ANCHOR LINKS
// ==========================================
document.querySelectorAll('a[href^="#"]').forEach(anchor => {
    anchor.addEventListener('click', function(e) {
        const href = this.getAttribute('href');
        if (href && href.length > 1) {
            e.preventDefault();
            const target = document.querySelector(href);
            if (target) {
                target.scrollIntoView({ behavior: 'smooth', block: 'start' });
            }
        }
    });
});

// ==========================================
// 4. ACTIVE NAVIGATION LINK ON SCROLL
// ==========================================
const sections = document.querySelectorAll('section[id]');
const navLinks = document.querySelectorAll('.nav-link');
const mobileNavLinks = document.querySelectorAll('.mobile-link');

function updateActiveNav() {
    const scrollPosition = window.scrollY + 100;

    sections.forEach(section => {
        const sectionTop = section.offsetTop;
        const sectionHeight = section.clientHeight;
        const sectionId = section.getAttribute('id');

        if (scrollPosition >= sectionTop && scrollPosition < sectionTop + sectionHeight) {
            // Update desktop nav
            navLinks.forEach(link => {
                link.classList.remove('active');
                if (link.getAttribute('href') === `#${sectionId}`) {
                    link.classList.add('active');
                }
            });

            // Update mobile nav
            mobileNavLinks.forEach(link => {
                link.classList.remove('active');
                if (link.getAttribute('href') === `#${sectionId}`) {
                    link.classList.add('active');
                }
            });
        }
    });
}

window.addEventListener('scroll', updateActiveNav);

// ==========================================
// 5. TYPING ANIMATION IN HERO
// ==========================================
const typingTexts = ["AI", "ML", "Chatbots", "Social Innovation"];
let textIndex = 0;
let charIndex = 0;
let isDeleting = false;
const typedTextElement = document.getElementById('typed-text');

function typeText() {
    if (!typedTextElement) return;

    const currentText = typingTexts[textIndex];
    
    if (!isDeleting) {
        typedTextElement.textContent = currentText.substring(0, charIndex + 1);
        charIndex++;

        if (charIndex === currentText.length) {
            isDeleting = true;
            setTimeout(typeText, 1500); // Pause before deleting
            return;
        }
    } else {
        typedTextElement.textContent = currentText.substring(0, charIndex - 1);
        charIndex--;

        if (charIndex === 0) {
            isDeleting = false;
            textIndex = (textIndex + 1) % typingTexts.length;
            setTimeout(typeText, 500); // Pause before typing next word
            return;
        }
    }

    const typingSpeed = isDeleting ? 50 : 100;
    setTimeout(typeText, typingSpeed);
}

// ==========================================
// 6. ANIMATED BACKGROUND CANVAS
// ==========================================
function initAnimatedBackground() {
    const canvas = document.getElementById('animated-bg');
    if (!canvas) return;

    const ctx = canvas.getContext('2d');
    canvas.width = window.innerWidth;
    canvas.height = window.innerHeight;

    const particles = [];
    const particleCount = 50;

    // Create particles
    for (let i = 0; i < particleCount; i++) {
        particles.push({
            x: Math.random() * canvas.width,
            y: Math.random() * canvas.height,
            vx: (Math.random() - 0.5) * 0.5,
            vy: (Math.random() - 0.5) * 0.5,
            size: Math.random() * 2 + 1
        });
    }

    function animate() {
        ctx.clearRect(0, 0, canvas.width, canvas.height);

        const isDark = html.classList.contains('dark');
        const particleColor = isDark ? 'rgba(168, 85, 247, 0.4)' : 'rgba(108, 99, 255, 0.3)';

        particles.forEach((particle, i) => {
            // Update position
            particle.x += particle.vx;
            particle.y += particle.vy;

            // Wrap around edges
            if (particle.x < 0) particle.x = canvas.width;
            if (particle.x > canvas.width) particle.x = 0;
            if (particle.y < 0) particle.y = canvas.height;
            if (particle.y > canvas.height) particle.y = 0;

            // Draw particle
            ctx.fillStyle = particleColor;
            ctx.beginPath();
            ctx.arc(particle.x, particle.y, particle.size, 0, Math.PI * 2);
            ctx.fill();

            // Draw connections
            particles.forEach((otherParticle, j) => {
                if (i === j) return;

                const dx = particle.x - otherParticle.x;
                const dy = particle.y - otherParticle.y;
                const distance = Math.sqrt(dx * dx + dy * dy);

                if (distance < 150) {
                    const opacity = isDark ? 0.2 : 0.15;
                    ctx.strokeStyle = isDark 
                        ? `rgba(168, 85, 247, ${opacity * (1 - distance / 150)})` 
                        : `rgba(108, 99, 255, ${opacity * (1 - distance / 150)})`;
                    ctx.lineWidth = 0.5;
                    ctx.beginPath();
                    ctx.moveTo(particle.x, particle.y);
                    ctx.lineTo(otherParticle.x, otherParticle.y);
                    ctx.stroke();
                }
            });
        });

        requestAnimationFrame(animate);
    }

    animate();

    // Handle resize
    window.addEventListener('resize', () => {
        canvas.width = window.innerWidth;
        canvas.height = window.innerHeight;
    });
}

// ==========================================
// 7. INTERSECTION OBSERVER FOR SCROLL ANIMATIONS
// ==========================================
function initScrollAnimations() {
    const observerOptions = {
        threshold: 0.1,
        rootMargin: '0px 0px -50px 0px'
    };

    const observer = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                entry.target.classList.add('visible');
            }
        });
    }, observerOptions);

    // Observe all animated elements
    const animatedElements = document.querySelectorAll(`
        .section-header,
        .section-badge,
        .about-card-wrapper,
        .skill-card,
        .project-card,
        .education-card-wrapper,
        .tech-skill-category,
        .certification-card,
        .achievement-card-wrapper,
        .contact-card-wrapper,
        .contact-method
    `);

    animatedElements.forEach(el => observer.observe(el));
}

// ==========================================
// 8. SKILLS PROGRESS BAR ANIMATION
// ==========================================
function initSkillProgressBars() {
    const observerOptions = {
        threshold: 0.5
    };

    const observer = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                const progressBars = entry.target.querySelectorAll('.tech-skill-progress');
                progressBars.forEach((bar, index) => {
                    setTimeout(() => {
                        const percent = bar.getAttribute('data-percent');
                        bar.style.width = percent + '%';
                        bar.classList.add('animated');
                    }, index * 100);
                });
            }
        });
    }, observerOptions);

    // Observe skill categories
    const skillCategories = document.querySelectorAll('.tech-skill-category');
    skillCategories.forEach(category => observer.observe(category));
}

// ==========================================
// 9. CONFETTI ANIMATION FOR ACHIEVEMENTS
// ==========================================
function initConfetti() {
    const container = document.querySelector('.confetti-container');
    if (!container) return;

    for (let i = 0; i < 20; i++) {
        const confetti = document.createElement('div');
        confetti.style.position = 'absolute';
        confetti.style.width = '8px';
        confetti.style.height = '8px';
        confetti.style.background = '#fbbf24';
        confetti.style.borderRadius = '50%';
        confetti.style.left = Math.random() * 100 + '%';
        confetti.style.top = Math.random() * 100 + '%';
        confetti.style.opacity = '0.6';
        confetti.style.animation = `confetti-fall ${3 + Math.random() * 2}s linear infinite`;
        confetti.style.animationDelay = Math.random() * 2 + 's';
        container.appendChild(confetti);
    }
}

// Add confetti animation to CSS (dynamic)
const style = document.createElement('style');
style.textContent = `
    @keyframes confetti-fall {
        0% {
            transform: translateY(0) rotate(0deg);
        }
        100% {
            transform: translateY(-30px) translateX(${Math.random() * 20 - 10}px) rotate(360deg);
        }
    }
`;
document.head.appendChild(style);

// ==========================================
// 10. NAVBAR SCROLL EFFECT
// ==========================================
const navbar = document.getElementById('navbar');

window.addEventListener('scroll', () => {
    if (window.scrollY > 50) {
        navbar.classList.add('scrolled');
    } else {
        navbar.classList.remove('scrolled');
    }
});

// ==========================================
// 11. INITIALIZE EVERYTHING ON DOM LOAD
// ==========================================
document.addEventListener('DOMContentLoaded', () => {
    // Start typing animation
    setTimeout(typeText, 500);
    
    // Initialize animated background
    initAnimatedBackground();
    
    // Initialize scroll animations
    initScrollAnimations();
    
    // Initialize skill progress bars
    initSkillProgressBars();
    
    // Initialize confetti
    initConfetti();
    
    // Update active nav on load
    updateActiveNav();
});

// ==========================================
// 12. PERFORMANCE OPTIMIZATIONS
// ==========================================

// Debounce function for scroll events
function debounce(func, wait) {
    let timeout;
    return function executedFunction(...args) {
        const later = () => {
            clearTimeout(timeout);
            func(...args);
        };
        clearTimeout(timeout);
        timeout = setTimeout(later, wait);
    };
}

// Throttle function for frequent events
function throttle(func, limit) {
    let inThrottle;
    return function(...args) {
        if (!inThrottle) {
            func.apply(this, args);
            inThrottle = true;
            setTimeout(() => inThrottle = false, limit);
        }
    };
}

// Use throttled scroll handler
const throttledScroll = throttle(() => {
    updateActiveNav();
}, 100);

window.addEventListener('scroll', throttledScroll);

// ==========================================
// 13. ACCESSIBILITY ENHANCEMENTS
// ==========================================

// Add keyboard navigation for mobile menu
if (mobileMenuBtn) {
    mobileMenuBtn.addEventListener('keydown', (e) => {
        if (e.key === 'Enter' || e.key === ' ') {
            e.preventDefault();
            mobileMenuBtn.click();
        }
    });
}

// Add focus trap for mobile menu
const focusableElements = 'button, [href], input, select, textarea, [tabindex]:not([tabindex="-1"])';

function trapFocus(element) {
    const focusable = element.querySelectorAll(focusableElements);
    const firstFocusable = focusable[0];
    const lastFocusable = focusable[focusable.length - 1];

    element.addEventListener('keydown', function(e) {
        if (e.key === 'Tab') {
            if (e.shiftKey) {
                if (document.activeElement === firstFocusable) {
                    lastFocusable.focus();
                    e.preventDefault();
                }
            } else {
                if (document.activeElement === lastFocusable) {
                    firstFocusable.focus();
                    e.preventDefault();
                }
            }
        }

        if (e.key === 'Escape') {
            mobileMenuBtn.classList.remove('active');
            mobileMenu.classList.remove('active');
            mobileMenuBackdrop.classList.remove('active');
            mobileMenuBtn.focus();
        }
    });
}

if (mobileMenu) {
    trapFocus(mobileMenu);
}

// ==========================================
// 14. CONSOLE LOG (Optional)
// ==========================================
console.log('%c👋 Welcome to my portfolio!', 'color: #6C63FF; font-size: 20px; font-weight: bold;');
console.log('%cBuilt with ❤️ by Dnyaneshwari Pawar', 'color: #3B82F6; font-size: 14px;');

// ==========================================
// 15. PRELOAD CRITICAL RESOURCES
// ==========================================
window.addEventListener('load', () => {
    // Add loaded class to body for any load-dependent animations
    document.body.classList.add('loaded');
});

// ==========================================
// 16. ERROR HANDLING
// ==========================================
window.addEventListener('error', (e) => {
    console.error('An error occurred:', e.error);
});

// ==========================================
// 17. PREVENT FOUC (Flash of Unstyled Content)
// ==========================================
document.documentElement.style.visibility = 'visible';
